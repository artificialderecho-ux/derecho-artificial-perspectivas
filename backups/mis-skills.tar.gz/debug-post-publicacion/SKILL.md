---
name: debug-post-publicacion
description: "Ayuda a debuggear cuando npm run publish:post falla. Analiza errores, explica por qué fallaron las validaciones, y da instrucciones concretas para arreglar. Usar cuando el usuario dice 'falló la publicación', 'error en publish', 'qué pasó?'."
---

# Debug: Publicación de Posts Fallida

## 🎯 Propósito

Cuando `npm run publish:post` falla, este skill:
- 🔍 Analiza el error reportado
- 📋 Explica por qué falló cada validación
- ✅ Da instrucciones concretas para arreglarlo
- 🚀 Guía la reintento

---

## 📊 Validaciones y errores comunes

### 1. Estructura

#### Error: "Carpeta no existe"
```
❌ Carpeta no existe: content/jurisprudencia/mi-post
```

**Causa:** El post no está en la carpeta correcta.

**Arreglo:**
```bash
# Crear la carpeta
mkdir -p content/jurisprudencia/mi-post

# Copiar el MDX
cp ~/Downloads/mi-post.mdx content/jurisprudencia/mi-post/index.mdx
```

---

#### Error: "Archivo no existe: index.mdx"
```
❌ Archivo no existe: content/jurisprudencia/mi-post/index.mdx
```

**Causa:** El archivo `.mdx` tiene otro nombre.

**Arreglo:**
```bash
# El archivo DEBE llamarse index.mdx
mv content/jurisprudencia/mi-post/mipost.mdx content/jurisprudencia/mi-post/index.mdx
```

---

#### Error: "Frontmatter no encontrado o formato inválido"
```
❌ Frontmatter no encontrado o formato inválido (debe estar entre --- y ---)
```

**Causa:** El frontmatter no está bien formado.

**Arreglo:** Asegúrate que el MDX empieza exactamente así:
```yaml
---
title: "Mi título"
date: "2026-03-19"
section: "jurisprudencia"
slug: "mi-post"
---

# Contenido aquí
```

**Nota:** Debe haber un salto de línea DESPUÉS de `---` inicial y ANTES del primer campo.

---

### 2. Frontmatter

#### Error: "title: String must contain at least 5 character(s)"
```
❌ title: String must contain at least 5 character(s)
```

**Causa:** El título es muy corto.

**Arreglo:**
```yaml
title: "IA"  # ← Malo (2 caracteres)
title: "La inteligencia artificial y el derecho"  # ← Bien (44 caracteres)
```

---

#### Error: "date debe ser ISO 8601 (YYYY-MM-DD)"
```
❌ date debe ser ISO 8601 (YYYY-MM-DD)
```

**Causa:** El formato de la fecha es incorrecto.

**Arreglo:**
```yaml
date: "19/03/2026"      # ← Malo
date: "March 19, 2026"  # ← Malo
date: "2026-03-19"      # ← Bien (ISO 8601)
```

---

#### Error: "slug debe ser lowercase con guiones"
```
❌ slug debe ser lowercase con guiones
```

**Causa:** El slug tiene mayúsculas o espacios.

**Arreglo:**
```yaml
slug: "Mi Nuevo Post"     # ← Malo (mayúsculas y espacios)
slug: "mi_nuevo_post"     # ← Malo (guiones bajos)
slug: "mi-nuevo-post"     # ← Bien (lowercase + guiones)
```

---

#### Error: "section no válida"
```
❌ section must be one of: jurisprudencia, normativa, ...
```

**Causa:** El nombre de la sección es incorrecto.

**Arreglo:**
```yaml
section: "derecho-ia"      # ← Malo
section: "etica-ia"        # ← Bien
```

Secciones válidas:
- `jurisprudencia`
- `normativa`
- `firma-scarpa`
- `etica-ia`
- `propiedad-intelectual-ia`
- `ia-global`
- `guias`

---

### 3. Coherencia

#### Error: "section en frontmatter no coincide con carpeta"
```
❌ Incoherencia: section en frontmatter ("normativa") no coincide con carpeta ("jurisprudencia")
```

**Causa:** La carpeta y el frontmatter están desalineados.

**Arreglo:**
```
Opción A: Cambiar el frontmatter
content/jurisprudencia/mi-post/index.mdx
---
section: "jurisprudencia"  # ← Cambiar de "normativa"
---

Opción B: Mover la carpeta
mv content/jurisprudencia/mi-post content/normativa/mi-post
```

---

#### Error: "slug en frontmatter no coincide con carpeta"
```
⚠️ slug en frontmatter ("otro-slug") no coincide con carpeta ("mi-post")
```

**Causa:** El slug del frontmatter es diferente al nombre de la carpeta.

**Arreglo:**
```
Opción A: Cambiar el frontmatter
content/jurisprudencia/mi-post/index.mdx
---
slug: "mi-post"  # ← Cambiar de "otro-slug"
---

Opción B: Renombrar la carpeta
mv content/jurisprudencia/mi-post content/jurisprudencia/otro-slug
```

---

### 4. PDF Policy

#### Error: "sección requiere PDF"
```
❌ Sección "jurisprudencia" requiere PDF. Agrega campo "pdf" en frontmatter
```

**Causa:** `jurisprudencia` y `normativa` REQUIEREN PDF.

**Arreglo:**
```yaml
# Agregar al frontmatter:
pdf: "/fuentes/Sentencia_TJUE_20260319.pdf"
```

---

#### Error: "sección no permite PDF"
```
❌ Sección "firma-scarpa" no permite PDF. Remueve el campo "pdf" del frontmatter
```

**Causa:** `firma-scarpa` no permite PDF.

**Arreglo:**
```yaml
# Eliminar esta línea:
# pdf: "/fuentes/Analisis.pdf"
```

---

#### Error: "PDF esperado no existe"
```
⚠️ PDF esperado no existe: /fuentes/Sentencia.pdf
```

**Causa:** El PDF está en el frontmatter pero no se copió a `public/fuentes/`.

**Arreglo:**
```bash
# Copiar el PDF
cp ~/Downloads/Sentencia.pdf public/fuentes/

# O verificar que existe
ls public/fuentes/Sentencia.pdf
```

---

### 5. Assets

#### Error: "Imagen no existe"
```
⚠️ Imagen no existe: /images/diagrama.png
```

**Causa:** La imagen está referenciada pero no existe en `public/images/`.

**Arreglo:**
```bash
# Verificar que existe
ls public/images/diagrama.png

# O copiarla
cp ~/Downloads/diagrama.png public/images/
```

---

#### Error: "Componente importado no existe"
```
⚠️ Componente importado no existe: @/components/MiComponente
```

**Causa:** El componente no existe en `src/components/`.

**Arreglo:**
```
Opción A: Crear el componente
src/components/MiComponente.tsx

Opción B: Usar un componente existente
Cambiar import en el MDX
```

---

### 6. Routing

#### Error: "Página dinámica no existe"
```
❌ Página dinámica no existe: src/app/jurisprudencia/[slug]/page.tsx
```

**Causa:** La página dinámica para esa sección no existe.

**Arreglo:** Contactar al equipo de desarrollo. Las páginas dinámicas deben existir para cada sección.

---

#### Error: "Conflicto: página estática"
```
❌ Conflicto de routing: existe página estática src/app/jurisprudencia/mi-post/page.tsx
```

**Causa:** Existe una página estática que hace override.

**Arreglo:** Eliminar la página estática.
```bash
rm src/app/jurisprudencia/mi-post/page.tsx
```

---

### 7. Git State

#### Error: "No estás en main"
```
❌ No estás en 'main', estás en 'feature-branch'
```

**Causa:** No estás en la rama `main`.

**Arreglo:**
```bash
# Cambiar a main
git checkout main

# O si ya hiciste cambios, hacer commit primero
git commit -m "wip: cambios antes de publicar"
git checkout main
```

---

#### Error: "Working tree no limpio"
```
❌ Working tree no limpio. Cambios sin commitear
```

**Causa:** Hay cambios sin commitear.

**Arreglo:**
```bash
# Ver cambios
git status

# Opción A: Commitear
git add .
git commit -m "wip: antes de publicar post"

# Opción B: Descartar
git checkout -- .
```

---

### 8. Build

#### Error: "typecheck failed"
```
❌ typecheck failed
```

**Causa:** Hay errores de TypeScript.

**Arreglo:**
```bash
# Ver errores
npm run typecheck

# Fijar según los errores reportados
# (Generalmente es mal tipado en el MDX o componente)
```

---

#### Error: "lint failed"
```
❌ lint failed
```

**Causa:** Hay errores de ESLint.

**Arreglo:**
```bash
# Ver errores
npm run lint

# Auto-fijar
npm run lint -- --fix

# Hacer commit
git add .
git commit -m "fix: lint issues"
```

---

#### Error: "build failed"
```
❌ build failed
```

**Causa:** El build de Next.js falla.

**Arreglo:**
```bash
# Ver errores detallados
npm run build

# Generalmente es un import incorrecto o componente roto
# Verificar que todos los imports existen
```

---

## 🔄 Flujo de debugging

### Paso 1: Obtener el error exacto

Cuando el usuario reporta que falló, pedirle:
```
Por favor, copia el error que viste en la terminal.
```

### Paso 2: Analizar el error

Buscar en esta guía qué validación falló.

### Paso 3: Explicar el arreglo

Dar instrucciones concretas y ejemplos.

### Paso 4: Validar antes de reintentar

Usar el skill `validar-post-antes-publicar` para asegurarse que está listo.

### Paso 5: Reintentar

```bash
npm run publish:post section/slug
```

---

## 📊 Tabla rápida: Error → Arreglo

| Error | Categoría | Arreglo |
|-------|-----------|---------|
| Carpeta no existe | Estructura | `mkdir -p content/<section>/<slug>` |
| index.mdx no existe | Estructura | Rename a `index.mdx` |
| Frontmatter inválido | Estructura | Revisar formato (entre `---` y `---`) |
| title corto | Frontmatter | Mínimo 5 caracteres |
| date inválida | Frontmatter | Usar ISO 8601 (YYYY-MM-DD) |
| slug inválido | Frontmatter | Lowercase + guiones |
| section no válida | Frontmatter | Usar una de las 7 secciones |
| Incoherencia section | Coherencia | Alinear carpeta y frontmatter |
| Incoherencia slug | Coherencia | Alinear carpeta y frontmatter |
| PDF requerido | PDF Policy | Agregar `pdf: "/fuentes/..."` |
| PDF no permitido | PDF Policy | Eliminar campo `pdf` |
| PDF no existe | Assets | Copiar a `public/fuentes/` |
| Imagen no existe | Assets | Verificar `/images/...` |
| Componente no existe | Assets | Verificar import o crear componente |
| Página dinámica no existe | Routing | Contactar equipo dev |
| Página estática conflicto | Routing | Eliminar página estática |
| No en main | Git | `git checkout main` |
| Working tree sucio | Git | `git commit -m "wip: ..."` |
| typecheck failed | Build | Ver errores con `npm run typecheck` |
| lint failed | Build | Fijar con `npm run lint -- --fix` |
| build failed | Build | Ver errores con `npm run build` |

---

## 💡 Tips de debugging

1. **Leer el error completo:** El error dice exactamente qué falta.
2. **Copiar el JSON:** Si el script devuelve JSON, copiar y analizar.
3. **Un error a la vez:** Fijar el primero, reintentar, fijar el siguiente.
4. **Validar antes de publicar:** Usar `validar-post-antes-publicar` entre intentos.
5. **Git limpio:** Siempre hacer `git pull` antes de intentar publicar.

---
