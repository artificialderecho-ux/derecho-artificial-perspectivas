---
name: hook-firma-scarpa
description: "Genera un artículo MDX hook optimizado para SEO a partir de un informe PDF para publicar en la sección Firma Scarpa de derechoartificial.com. Usar cuando el usuario suba un PDF de informe propio y pida un artículo, hook, post o MDX para Firma Scarpa. Activar también cuando el usuario diga 'tengo un informe', 'quiero publicar esto en Firma Scarpa', 'necesito un hook para este PDF', o cualquier variante que combine un documento de autoría propia con la sección Firma Scarpa."
---

# Hook para Firma Scarpa — MDX desde informe PDF

## Contexto

Firma Scarpa es la sección de análisis de autor en derechoartificial.com. Los posts de esta sección son artículos que actúan como **hook** (gancho editorial) para que el lector descargue el informe completo en PDF. No son resúmenes: son piezas independientes que seleccionan los argumentos más potentes del informe, crean tensión intelectual y terminan con un CTA de descarga.

El frontmatter debe ser compatible con el skill `analisis-juridico-ia` y con el skill `publish-post-derechoartificial`.

---

## Flujo de trabajo

### Paso 1 — Leer el PDF completo

Leer el documento PDF adjunto en su totalidad antes de escribir nada. Identificar:

- **Tesis central** del informe: ¿qué argumento sostiene?
- **Datos más impactantes**: cifras, porcentajes, reducciones de tiempo, tasas de acierto, casos reales
- **La pregunta incómoda**: el dilema o tensión que el informe aborda y que ningún lector puede ignorar
- **Lo que el artículo NO contiene**: qué queda reservado para el PDF (para justificar la descarga)
- **Autor y fuentes principales**: para el frontmatter y las referencias

### Paso 2 — Construir el frontmatter

```mdx
---
title: "[Título con keyword principal — incluir nombre del sistema/caso + contexto jurídico]"
description: "[1-2 frases. Qué analiza, dato más impactante, conclusión clave. Máx. 160 caracteres]"
date: "[YYYY-MM-DD — fecha actual]"
tags: ["[término clave 1]", "[término clave 2]", "[término clave 3]", "[término clave 4]", "[término clave 5]"]
section: "firma-scarpa"
category: "analisis-juridico"
author: "Ricardo Scarpa"
slug: "[kebab-case con keywords principales del título]"
readingTime: "[X min — calcular: ~200 palabras/min]"
pdf: "/fuentes/[nombre-exacto-del-archivo.pdf]"
---
```

**Reglas del frontmatter:**
- `section` siempre `"firma-scarpa"` para este skill
- `author` siempre `"Ricardo Scarpa"`
- `pdf` usar el nombre exacto del archivo PDF tal como se llama en el sistema (sin ruta de Downloads)
- `slug` debe contener las keywords más relevantes del informe
- `tags` máximo 5, deben incluir el nombre propio del sistema/caso analizado

### Paso 3 — Escribir el artículo hook

**Estructura obligatoria:**

1. **Apertura con el dato o escena más impactante** (no empezar con contexto genérico sobre IA)
2. **2-4 secciones temáticas** con H2 doctrinales (no IRAC, no genéricos)
3. **La pregunta que el lector no puede evitar** — el dilema central del informe
4. **"Lo que viene en el informe completo"** — sección explícita que anticipa qué encontrará el lector en el PDF sin desvelarlo todo
5. **CTA de descarga** integrado naturalmente, en blockquote
6. **Conclusiones** en bullets accionables (5 máximo)

**Longitud objetivo:** 800-1.100 palabras. Suficiente para enganchar, no tanto como para sustituir el informe.

### Reglas de estilo (obligatorias)

**Voz humana con autoridad:** El texto lo escribe un jurista con criterio propio, no una IA que resume. Esto significa:

- Variación real en longitud de oraciones: cortas, medias y largas mezcladas
- Reflexiones que parecen surgir mientras se escribe: "Lo que más me llama la atención...", "Aquí es donde el análisis se complica", "Y esto, en el ámbito jurídico, no es un detalle menor"
- Alguna duda razonable expresada: cuando el informe no da una respuesta definitiva, decirlo
- Conectores variados: "Sin embargo", "Dicho esto", "Ahora bien", "Lo que resulta llamativo es", "Conviene recordar que" — nunca repetir el mismo patrón
- Sin listas en el cuerpo del texto salvo las conclusiones finales
- Latinismos en cursiva: *prima facie*, *Human in the Loop*, etc.

**SEO:**
- La keyword principal aparece en el primer párrafo
- Los H2 incluyen keywords secundarias de forma natural
- La meta description (campo `description`) responde: qué analiza + dato más potente + conclusión

### Paso 4 — Entregar el archivo

Guardar el MDX en `/mnt/user-data/outputs/[slug].mdx` y presentarlo con `present_files`.

Tras el archivo, mostrar el bloque PowerShell de publicación:

```powershell
cd C:\Proyectos\derecho-artificial
mkdir "content\firma-scarpa\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-MDX].mdx" "content\firma-scarpa\[SLUG]\index.mdx"
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-PDF].pdf" "public\fuentes\"
node scripts/update-glosario.cjs
git add .
git commit -m "feat(firma-scarpa): [título corto en minúsculas]"
git push
```

Y la URL resultante:
`https://www.derechoartificial.com/firma-scarpa/[SLUG]`

---

## Qué hace un buen hook (y qué lo arruina)

**Hace bien:**
- Revela los datos más impactantes desde el principio
- Crea tensión intelectual alrededor del dilema central del informe
- Deja al lector con preguntas que solo el PDF puede responder
- El CTA de descarga aparece como consecuencia natural del texto, no como banner

**Arruina el hook:**
- Empezar con contexto genérico sobre IA o Derecho
- Resumir el informe capítulo por capítulo
- Revelar las conclusiones principales antes del CTA
- Usar el mismo tono neutro de un resumen ejecutivo
- Estructuras simétricas y perfectas que no suenan a persona real

---

## Ejemplo de estructura de H2 bien resuelta

Para un informe sobre IA en la justicia argentina:

✅ `## Un sistema que no adivina, sino que deduce`
✅ `## Los números que cambiaron la conversación`
✅ `## La pregunta que nadie puede evitar`
✅ `## Lo que viene en el informe completo`

❌ `## Contexto y Marco Teórico`
❌ `## Análisis del Sistema`
❌ `## Conclusiones y Recomendaciones`
