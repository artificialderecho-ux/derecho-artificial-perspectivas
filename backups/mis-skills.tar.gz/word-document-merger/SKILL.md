---
name: word-document-merger
description: "Fusiona múltiples documentos Word (.docx) en uno solo sin modificar ni una palabra. Preserva formato, estilos, notas al pie, tablas e imágenes. Ideal para integrar capítulos, secciones, partes de análisis jurídicos o informes modulares en un único documento. Usar cuando el usuario pida: 'unir documentos Word', 'combinar docx', 'mergear partes en un solo archivo', 'consolidar capítulos', o cualquier variante."
---

# Word Document Merger — Skill de Fusión de Documentos

## Rol y Misión

Actúas como **especialista en consolidación de documentos Word**, con capacidad para fusionar múltiples archivos `.docx` preservando perfectamente:

- ✅ Contenido palabra por palabra (sin modificaciones)
- ✅ Formatos originales (negritas, cursivas, subrayados)
- ✅ Estilos de párrafo (Heading 1, Body Text, etc.)
- ✅ Notas al pie y referencias cruzadas
- ✅ Tablas, imágenes, hipervínculos
- ✅ Numeración de páginas
- ✅ Espaciado entre párrafos

---

## Cuándo Usar Este Skill

**Usar word-document-merger cuando:**

- Usuario carga múltiples archivos `.docx` y pide "unirlos" o "combinarlos"
- Necesita consolidar capítulos/partes de un análisis jurídico en un único documento
- Desea preservar exactamente el contenido sin ediciones
- Requiere mantener estructura modular pero entregar un solo archivo
- Pide "mergear", "fusionar", "consolidar", "juntar" documentos Word
- Tiene 2-50 archivos `.docx` que deben convertirse en 1

**NO usar cuando:**

- Solo hay 1 documento (no hay nada que fusionar)
- Los archivos no son `.docx` (usar skills específicos de otros formatos)
- Necesita reorganizar, editar o resumir el contenido (eso es edición, no fusión)
- Pide cambios en el contenido durante la fusión

---

## Código Recomendado: Python con python-docx

```python
#!/usr/bin/env python3
from docx import Document
from copy import deepcopy
import os

def merge_docx_files(source_files, output_path, include_page_breaks=True):
    """
    Fusiona múltiples archivos .docx en uno solo sin modificar contenido
    
    Args:
        source_files: Lista de rutas a archivos .docx a fusionar
        output_path: Ruta del archivo de salida
        include_page_breaks: Insertar PageBreak entre documentos (default: True)
    
    Returns:
        output_path si éxito, None si error
    """
    
    if not source_files:
        print("ERROR: No se proporcionaron archivos")
        return None
    
    try:
        # 1. Cargar primer documento como base
        master_doc = Document(source_files[0])
        print(f"✓ Base: {os.path.basename(source_files[0])}")
        
        # 2. Procesar documentos adicionales
        for source_file in source_files[1:]:
            if include_page_breaks:
                master_doc.add_page_break()
            
            source_doc = Document(source_file)
            
            # Copiar CADA elemento del documento fuente (sin cambios)
            # deepcopy preserva TODO: estilos, notas al pie, formatos
            for element in source_doc.element.body:
                new_element = deepcopy(element)
                master_doc.element.body.append(new_element)
            
            print(f"✓ Agregado: {os.path.basename(source_file)}")
        
        # 3. Guardar
        master_doc.save(output_path)
        
        # 4. Validación
        file_size = os.path.getsize(output_path) / 1024
        print(f"\n✅ FUSIÓN COMPLETADA")
        print(f"  Archivo: {output_path}")
        print(f"  Documentos: {len(source_files)}")
        print(f"  Tamaño: {file_size:.1f} KB")
        
        return output_path
    
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return None

# USO
merge_docx_files([
    '/path/doc1.docx',
    '/path/doc2.docx',
    '/path/doc3.docx'
], '/path/output.docx', include_page_breaks=True)
```

---

## Principio Fundamental

**Este skill NO modifica contenido. Solo concatena archivos.**

- Si necesitas editar → usar otros skills
- Si necesitas reorganizar → especificar orden antes de fusionar
- Si necesitas cambiar formato → usar skills de edición posteriores

---

## Casos de Uso Reales

### Caso: Análisis Jurídico Modular (Jane Doe v. xAI)
```
INPUT: jane_doe_01.docx ... jane_doe_16.docx
OUTPUT: JANE_DOE_COMPLETE.docx (16 documentos unidos, 1 solo archivo)
RESULTADO: Análisis completo, listo para publicación o litigio
```

### Caso: Tesis Doctoral
```
INPUT: cap1, cap2, ..., cap20 + portada + índice + bibliografía
OUTPUT: Tesis_Completa.docx (sin cambios de contenido)
RESULTADO: Documento único para defensa
```

### Caso: Informe Corporativo
```
INPUT: 5 secciones por equipos diferentes
OUTPUT: Informe_Q3_2026.docx (consolidado)
RESULTADO: Presentación a junta directiva
```

---

## Velocidad y Escalabilidad

| Rango | Tiempo | Tamaño Esperado |
|-------|--------|-----------------|
| 2-10 documentos | < 2 segundos | Varía |
| 20 documentos | 3-5 segundos | Varía |
| 50+ documentos | 10-20 segundos | Varía |

**Garantía:** Contenido 100% intacto. Ningún byte se pierde o modifica.

