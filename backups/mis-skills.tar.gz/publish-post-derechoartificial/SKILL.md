---
name: publish-post-derechoartificial
description: "Guía al usuario a publicar posts en derechoartificial.com. Valida MDX + PDF, genera comando de publicación, reporta URL canónica. Usar cuando el usuario diga 'tengo el post listo', 'publicar post', 'subir a la web', o cualquier variante de publicación."
---

# Publicar Post en derechoartificial.com

## 📌 Contexto del proyecto (versión mejorada)

- **Repositorio:** `C:\Proyectos\derecho-artificial` (Windows) o `~/derecho-artificial` (Mac/Linux)
- **Secciones:** `jurisprudencia`, `normativa`, `firma-scarpa`, `etica-ia`, `propiedad-intelectual-ia`, `ia-global`, `guias`
- **Estructura:** `content/<section>/<slug>/index.mdx`
- **PDFs:** `public/fuentes/<NombreDelPdf>.pdf`
- **Scripts nuevos:** `scripts/publish-post.mjs` (validación) + `scripts/publish-workflow.mjs` (orquestación)

---

## 🎯 Flujo de 3 pasos (MEJORADO)

### Paso 1: Verificar que el MDX está listo

El usuario debe tener:
- ✅ Archivo `.mdx` en `Downloads` (o ruta conocida)
- ✅ PDF (si la sección lo requiere) en `Downloads`
- ✅ Frontmatter completo en el MDX

**Campos mínimos del frontmatter:**
```yaml
---
title: "Título del artículo (5-200 caracteres)"
date: "2026-03-19"
section: "jurisprudencia"  # O la sección correspondiente
slug: "nippon-life-openai"  # Lowercase, guiones, sin espacios
category: "TJUE"  # Según sección (opcional si no existe enum)
description: "Breve descripción"
pdf: "/fuentes/Nippon_Life_v_OpenAI.pdf"  # Solo si la sección lo requiere
tags: ["IA", "copyright", "jurisprudencia"]  # Opcional
---
```

**Validar manualmente:**
- [ ] `title` tiene 5-200 caracteres
- [ ] `date` está en formato ISO 8601 (YYYY-MM-DD)
- [ ] `section` es una de las 7 secciones conocidas
- [ ] `slug` es lowercase y usa guiones (no espacios)
- [ ] `category` coincide con las permitidas para esa sección
- [ ] Si `section` es `jurisprudencia` o `normativa`: debe tener `pdf`
- [ ] Si `section` es `firma-scarpa`: NO debe tener `pdf`

---

### Paso 2: Leer frontmatter y extraer información

Antes de generar comando, **leer el archivo `.mdx`** para extraer:
- `section` → determina carpeta destino
- `slug` → nombre de carpeta y URL final
- `pdf` → nombre del archivo PDF (si existe)
- `date` → para el commit
- `title` → para el commit

Si el usuario no ha subido el MDX, **pedirle que lo adjunte** antes de continuar.

---

### Paso 3: Generar comando de publicación (AUTOMÁTICO)

Una vez verificado el MDX + frontmatter, generar el **comando único**:

#### Versión estándar (con PDF)

```powershell
cd C:\Proyectos\derecho-artificial

# 1. Crear carpeta y copiar MDX
mkdir "content\[SECTION]\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-ARCHIVO].mdx" "content\[SECTION]\[SLUG]\index.mdx"

# 2. Copiar PDF
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-PDF].pdf" "public\fuentes\"

# 3. Validar y publicar (automatizado)
npm run publish:post [SECTION]/[SLUG]
```

#### Versión sin PDF

```powershell
cd C:\Proyectos\derecho-artificial

# 1. Crear carpeta y copiar MDX
mkdir "content\[SECTION]\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-ARCHIVO].mdx" "content\[SECTION]\[SLUG]\index.mdx"

# 2. Validar y publicar (automatizado)
npm run publish:post [SECTION]/[SLUG]
```

#### Versión PDF ya copiado

```powershell
cd C:\Proyectos\derecho-artificial

# 1. Crear carpeta y copiar MDX
mkdir "content\[SECTION]\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-ARCHIVO].mdx" "content\[SECTION]\[SLUG]\index.mdx"

# 2. Validar y publicar (PDF ya en public\fuentes\)
npm run publish:post [SECTION]/[SLUG]
```

---

## 📋 Lo que hace `npm run publish:post` (AUTOMÁTICO)

El comando ejecuta **5 fases automáticas:**

1. **Pre-flight (Validación):**
   - ✓ Estructura correcta (carpeta, `index.mdx`)
   - ✓ Frontmatter válido (schema Zod)
   - ✓ Assets existentes (imágenes, PDFs, imports)
   - ✓ Routing correcto (no conflictos dinámico/estático)
   - ✓ PDF policy según sección
   
2. **Git state check:**
   - ✓ Estás en rama `main`
   - ✓ Working tree limpio (sin cambios sin commitear)
   - ✓ Remote `origin` existe

3. **Publicar:**
   - `git add` contenido
   - `git commit` automático con mensaje correcto
   - `git pull --rebase` (sincronizar)
   - `git push` (publicar)

4. **Post-flight (Build checks):**
   - `npm run typecheck` (TypeScript)
   - `npm run lint` (ESLint)
   - `npm run build` (Next.js build)

5. **Verificación final:**
   - `npm run verify-posts` (si existe)

**Si algo falla en cualquier fase, el script para y reporta el error con claridad.**

---

## 📍 URL resultante

Después de publicar correctamente:

```
https://www.derechoartificial.com/[SECTION]/[SLUG]
```

**Nota sobre `ia-global`:** Si la sección es `ia-global`, la URL pública es:
```
https://www.derechoartificial.com/global-ia/[SLUG]
```

---

## 🚨 Casos especiales y warnings

### A. Slug diferente del nombre del archivo

Si el frontmatter tiene `slug: diferente-slug` pero la carpeta es `mi-post`:

**Acción:** Usar siempre el `slug` del frontmatter. Avisar:

> ⚠️ El slug en frontmatter ("diferente-slug") no coincide con la carpeta ("mi-post"). 
> La URL será: `/section/diferente-slug`

---

### B. Section no reconocida

Si el frontmatter tiene `section: nueva-seccion`:

**Acción:** Detener y preguntar:

> ❌ La sección "nueva-seccion" no es reconocida. Secciones válidas:
> - jurisprudencia
> - normativa
> - firma-scarpa
> - etica-ia
> - propiedad-intelectual-ia
> - ia-global
> - guias

---

### C. PDF requerido pero no proporcionado

**Secciones que requieren PDF:** `jurisprudencia`, `normativa`

**Acción:** Error (hard fail):

> ❌ La sección "jurisprudencia" requiere PDF. Agrega al frontmatter:
> ```yaml
> pdf: "/fuentes/NombreDelPdf.pdf"
> ```

---

### D. PDF no permitido en sección

**Sección que NO permite PDF:** `firma-scarpa`

**Acción:** Error (hard fail):

> ❌ La sección "firma-scarpa" no permite PDF. Remueve del frontmatter:
> ```yaml
> pdf: ...  # ← elimina esta línea
> ```

---

### E. Category inválida

Si `category` no está en el enum de la sección:

**Acción:** Warning (avisa pero permite):

> ⚠️ category "categoria-rara" no está en enum para "jurisprudencia".
> Valores válidos: CJCE, TJUE, AN, TS, AP, juzgado

---

### F. PDF en Downloads pero usuario dice "ya está en `public/fuentes/`"

**Acción:** Omitir el `Copy-Item` del PDF:

> ℹ️ El PDF ya está en `public\fuentes\`. El comando lo incluirá automáticamente en git.

---

## 📝 Formato de respuesta

**Estructura:**

1. **Confirmación breve** (2-3 líneas)
   ```
   Leído: section=jurisprudencia, slug=nippon-life-openai, pdf=Nippon_Life_v_OpenAI.pdf
   Validaciones pasadas: ✓ frontmatter, ✓ estructura, ✓ pdf policy
   Listo para publicar.
   ```

2. **Bloque PowerShell** (listo para copiar-pegar)
   ```powershell
   cd C:\Proyectos\derecho-artificial
   ...
   ```

3. **URL resultante**
   ```
   URL en producción (tras deploy de Vercel):
   https://www.derechoartificial.com/jurisprudencia/nippon-life-openai
   ```

4. **Nota post-publicación** (si aplica)
   ```
   Proximos pasos:
   1. El comando ejecutará validaciones automáticamente
   2. Si pasa, hará git push y build
   3. Esperar deploy de Vercel (verifica dashboard)
   4. Abrir URL y validar que esté visible
   ```

**No explicar cada línea del PowerShell. El usuario ya conoce el flujo.**

---

## ✅ Checklist: Validaciones automáticas

El script `npm run publish:post` valida automáticamente:

| Aspecto | Si falla |
|---------|----------|
| **Estructura** | Carpeta existe, `index.mdx` existe | ❌ Hard fail |
| **Frontmatter** | Campos mínimos, tipos, formato | ❌ Hard fail |
| **Section** | Debe estar en enum de 7 secciones | ❌ Hard fail |
| **Slug** | Lowercase + guiones, coincide con carpeta | ⚠️ Warning |
| **Category** | Si existe, valida contra enum | ⚠️ Warning |
| **Assets** | Imágenes, PDFs, imports existen | ⚠️ Warning |
| **PDF Policy** | Requerido en jurisprudencia/normativa, prohibido en firma-scarpa | ❌ Hard fail |
| **Routing** | Página dinámica existe, sin conflictos estáticos | ❌ Hard fail |
| **Git state** | main branch, working tree limpio | ❌ Hard fail |
| **Typecheck** | TypeScript OK | ❌ Hard fail |
| **Lint** | ESLint OK | ❌ Hard fail |
| **Build** | Next.js build OK | ❌ Hard fail |

---

## 🎯 Definition of Done

El post está **publicado cuando:**

- ✅ Validaciones `npm run publish:post` pasan (0 errores)
- ✅ Git push ejecutado exitosamente
- ✅ `npm run typecheck && npm run lint && npm run build` OK
- ✅ Deploy de Vercel completado
- ✅ Post visible en sección y Home (según aplique)
- ✅ Links internos y externos funcionan
- ✅ Imágenes cargan correctamente

---
