---
name: validar-post-antes-publicar
description: "Valida MDX + frontmatter antes de publicar. Usa cuando el usuario dice 'revisa mi post', 'está listo?', 'valida esto', o cuando necesita asegurarse que el post pasará las validaciones automáticas del script."
---

# Validar Post Antes de Publicar

## 🎯 Propósito

Este skill **revisa manualmente** un post MDX antes de intentar publicar, asegurando que:
- ✅ Frontmatter es válido
- ✅ Estructura es correcta
- ✅ No hay errores que bloqueen la publicación
- ✅ Está listo para `npm run publish:post`

**Cuándo usar:** Cuando el usuario tiene un post escrito y quiere validarlo antes de publicar.

---

## 📋 Checklist de validación

### 1. Estructura del archivo

- [ ] Existe carpeta: `content/<section>/<slug>/`
- [ ] Existe archivo: `index.mdx` (exactamente con ese nombre)
- [ ] El archivo tiene frontmatter al inicio (entre `---` y `---`)

### 2. Frontmatter: Campos obligatorios

Verificar que existen TODOS estos campos:

```yaml
---
title: "..."        # Obligatorio: 5-200 caracteres
date: "YYYY-MM-DD"  # Obligatorio: formato ISO 8601
section: "..."      # Obligatorio: una de las 7 secciones
slug: "..."         # Obligatorio: lowercase + guiones
---
```

### 3. Validar cada campo

#### `title`
- [ ] Tiene entre 5 y 200 caracteres
- [ ] No tiene caracteres especiales problemáticos
- [ ] No es genérico (ej: "Mi post")

#### `date`
- [ ] Formato exacto: `YYYY-MM-DD` (ej: `2026-03-19`)
- [ ] La fecha tiene sentido (no es futura 5 años)
- [ ] Está entre comillas

#### `section`
- [ ] Es una de estas 7 secciones:
  - `jurisprudencia`
  - `normativa`
  - `firma-scarpa`
  - `etica-ia`
  - `propiedad-intelectual-ia`
  - `ia-global`
  - `guias`

#### `slug`
- [ ] Es lowercase (no mayúsculas)
- [ ] Usa guiones, no espacios (ej: `nippon-life-openai`, no `nippon life openai`)
- [ ] Coincide con el nombre de la carpeta
- [ ] Tiene sentido (es un identificador único del post)

### 4. Campos opcionales (pero recomendados)

Verificar si existen y son válidos:

```yaml
category: "..."      # Opcional: debe estar en enum de la sección
description: "..."   # Opcional: breve resumen del post
pdf: "/fuentes/..."  # Obligatorio SI: section es jurisprudencia o normativa
tags: ["...", "..."] # Opcional: palabras clave
author: "..."        # Opcional (recomendado en firma-scarpa)
image: "..."         # Opcional: portada
```

#### `category` (si existe)
- [ ] Es válido para esa sección:
  - **jurisprudencia:** CJCE, TJUE, AN, TS, AP, juzgado
  - **normativa:** EU, ES, EEUU, internacional
  - **firma-scarpa:** análisis, comentario, propuesta
  - **etica-ia:** riesgos, gobernanza, principios
  - **propiedad-intelectual-ia:** copyright, patents, trade-secrets
  - **ia-global:** policy, research, industry
  - **guias:** tutorial, how-to, reference

#### `pdf` (si existe)
- [ ] Formato: `/fuentes/NombreSinEspacios.pdf`
- [ ] **SI `section` es `jurisprudencia` o `normativa`:** DEBE existir
- [ ] **SI `section` es `firma-scarpa`:** NO debe existir (error)
- [ ] Otros: opcional

### 5. Contenido MDX

- [ ] El contenido está después del frontmatter (después del segundo `---`)
- [ ] Tiene al menos 200 palabras (no es un stub)
- [ ] Las imágenes usan ruta `/images/...` (si hay imágenes)
- [ ] Los links internos son correctos

### 6. Validación de discoverability

- [ ] El `section` está reconocido (no es typo)
- [ ] Si `section` es `ia-global`, la URL será `/global-ia/<slug>` (automático)
- [ ] El post será visible en su sección destino

---

## 📝 Formato de validación

Cuando el usuario adjunte un `.mdx`, hacer:

**1. Revisar rápidamente**
```
Leído: [SECTION]/[SLUG]
```

**2. Listar hallazgos**
```
✅ Frontmatter válido
✅ Estructura correcta
⚠️ [Advertencia si existe]
❌ [Error si existe]
```

**3. Resumen**
```
✅ LISTO para publicar → npm run publish:post [SECTION]/[SLUG]
```

O:

```
❌ FALTA ARREGLAR antes de publicar:
1. [Error 1]
2. [Error 2]
```

**4. Si hay errores, dar instrucciones concretas**
```
Para arreglarlo:
- Edita el MDX y cambia: ...
- Agrega este campo: ...
- Remueve este campo: ...
```

---

## 🚨 Errores comunes

### Error 1: Falta el campo `pdf` en jurisprudencia/normativa

**Síntoma:** 
```
section: "jurisprudencia"
# FALTA: pdf: "..."
```

**Arreglo:**
```yaml
---
section: "jurisprudencia"
pdf: "/fuentes/NombreDeLaSentencia.pdf"  # ← Agrega esta línea
---
```

---

### Error 2: PDF en `firma-scarpa`

**Síntoma:**
```
section: "firma-scarpa"
pdf: "/fuentes/Analisis.pdf"  # ← NO permitido
```

**Arreglo:** Elimina la línea `pdf`.

---

### Error 3: Slug con espacios

**Síntoma:**
```
slug: "mi nuevo post"  # ← Espacios (INCORRECTO)
```

**Arreglo:**
```yaml
slug: "mi-nuevo-post"  # ← Guiones (CORRECTO)
```

---

### Error 4: `date` en formato incorrecto

**Síntoma:**
```
date: "19/03/2026"     # ← Formato europeo (INCORRECTO)
date: "March 19 2026"  # ← Texto (INCORRECTO)
```

**Arreglo:**
```yaml
date: "2026-03-19"     # ← ISO 8601 (CORRECTO)
```

---

### Error 5: `title` demasiado corto

**Síntoma:**
```
title: "IA"            # ← 2 caracteres (INCORRECTO)
```

**Arreglo:**
```yaml
title: "Regulación de la IA en Europa"  # ← 38 caracteres (CORRECTO)
```

---

## 🎯 Después de validar

Si todo está OK:

```
✅ Tu post está listo para publicar.

Próximo paso:
1. Copia el MDX a: content/[SECTION]/[SLUG]/index.mdx
2. Copia el PDF a: public/fuentes/ (si existe)
3. Ejecuta: npm run publish:post [SECTION]/[SLUG]
```

Si hay errores:

```
❌ Necesitas arreglar estos errores antes de publicar:

1. [Error 1] → Arreglalo así: ...
2. [Error 2] → Arreglalo así: ...

Una vez arreglado, vuelve a validar y luego publica.
```

---

## 🔗 Relación con otros skills

- **Este skill (`validar-post-antes-publicar`):** Validación MANUAL (pre-flight)
- **El skill `publish-post-derechoartificial`:** Genera comando de PUBLICACIÓN
- **El script `npm run publish:post`:** Validación AUTOMÁTICA + publicación

**Flujo recomendado:**
1. Usuario escribe el post
2. Usa este skill para validar (`validar-post-antes-publicar`)
3. Si hay errores, los arregla
4. Usa `publish-post-derechoartificial` para generar comando
5. Ejecuta `npm run publish:post` para publicar

---

## ✅ Validación rápida (checklist)

```
□ Frontmatter entre --- y ---?
□ Existe title (5-200 chars)?
□ Existe date en ISO 8601 (YYYY-MM-DD)?
□ Existe section (7 secciones válidas)?
□ Existe slug (lowercase + guiones)?
□ Si jurisprudencia/normativa: ¿tiene pdf?
□ Si firma-scarpa: ¿NO tiene pdf?
□ Slug coincide con carpeta?
□ Contenido tiene >200 palabras?
□ Imágenes usan /images/...?
□ ¿Listo!
```

---
