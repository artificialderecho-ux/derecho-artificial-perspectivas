---
name: courtlistener-analyzer
description: Analiza casos judiciales a partir de una URL de CourtListener. Extrae los hitos procesales más importantes, genera un resumen académico del estado actual del caso y entrega el resultado como archivo .mdx optimizado para SEO, listo para publicar en derechoartificial.com. Usar siempre que el usuario comparta un enlace de courtlistener.com, pida analizar un caso judicial, quiera saber el estado de un litigio, o mencione "docket", "caso judicial", "litigio federal", "PACER", "análisis de caso". Activar también ante frases como "analiza este caso", "¿en qué estado está este litigio?", "resume los hitos del caso", "qué ha pasado en este caso" cuando vayan acompañadas de una URL de CourtListener o de un número de docket federal. Si el usuario especifica "en inglés" o "in English", el output completo (incluyendo frontmatter) se genera en inglés formal académico-jurídico.
---

# CourtListener Case Analyzer

Skill para analizar casos judiciales federales de EE.UU. a partir de una URL de CourtListener, produciendo un archivo `.mdx` optimizado para SEO listo para publicar en derechoartificial.com. El output incluye: (1) ficha del caso, (2) cronología de hitos procesales clave y (3) resumen académico del estado actual.

---

## Paso 1: Detectar idioma del output

Antes de cualquier otra cosa, determina el idioma del output:

- **Por defecto**: español formal académico-jurídico
- **Si el usuario especifica "en inglés", "in English", "English version"** o similar → output íntegro en **inglés formal jurídico** (*formal legal English*)

En inglés se aplican estas reglas adicionales:
- Preferencia por el estilo del inglés jurídico internacional / estadounidense (jurisdicción federal US)
- Latinismos en cursiva: *prima facie*, *inter alia*, *res judicata*
- Sin calcos del español: no *"the norm contemplates"* → *"the provision establishes"*
- El `slug` y los `tags` del frontmatter también en inglés
- Los términos procesales se mantienen en inglés original (no traducidos): *discovery*, *motion to dismiss*, *summary judgment*

---

## Paso 2: Extraer el Docket ID de la URL

La URL de CourtListener sigue este patrón:
```
https://www.courtlistener.com/docket/{DOCKET_ID}/{case-slug}/
```

Ejemplo: `https://www.courtlistener.com/docket/68117049/the-new-york-times-company-v-microsoft-corporation/`
→ Docket ID: `68117049`

Extrae el DOCKET_ID del número que aparece tras `/docket/` en la URL. El *case-slug* también sirve para inferir el nombre de las partes antes de obtener datos completos.

---

## Paso 3: Intentar acceder a datos estructurados de CourtListener

> **IMPORTANTE**: Desde la versión v4.3, la API REST de CourtListener requiere autenticación con token. Las solicitudes anónimas reciben un 401 Unauthorized. Si la API falla, pasa directamente al Paso 4.

Intenta hacer `web_fetch` a estos endpoints:

```
https://www.courtlistener.com/api/rest/v4/dockets/{DOCKET_ID}/
https://www.courtlistener.com/api/rest/v4/docket-entries/?docket={DOCKET_ID}&order_by=date_filed&page_size=50
```

Si obtienes datos, extrae: `case_name`, `docket_number`, `court`, `date_filed`, `date_terminated`, `assigned_to_str`, `cause`, `nature_of_suit`, y las entradas procesales (`date_filed`, `description`, `entry_number`).

**Si la API falla (401/403/error de permisos)**: Omite este paso y ve al Paso 4.

---

## Paso 4: Búsqueda web

Usa `web_search` para obtener y enriquecer la información del caso. Lanza al menos 4 búsquedas:

1. `"{case name}" docket {docket_number}` — datos procesales básicos
2. `"{case name}" ruling order decision 2024 2025 2026` — resoluciones recientes
3. `"{case name}" legal analysis {área del derecho}` — análisis académicos y doctrinales
4. `"{case name}" latest developments settlement appeal` — estado más reciente

Fuentes prioritarias:
- Justia Dockets, PACER Public Access, CourtListener (resultados indexados)
- SSRN (artículos académicos)
- Law360, Reuters Legal, Bloomberg Law, The National Law Review
- Blogs jurídicos especializados en el área del caso

---

## Paso 5: Construir el frontmatter MDX

Usa la estructura estándar de derechoartificial.com. El `section` para análisis de casos judiciales es siempre `"jurisprudencia"`.

**En español:**
```mdx
---
title: "[Nombre corto del caso]: [Cuestión jurídica central en 6-10 palabras]"
description: "[1-2 frases. Qué caso analiza + cuál es la cuestión jurídica + estado actual. Máx. 160 caracteres]"
date: "[YYYY-MM-DD — fecha de generación del análisis]"
tags: ["[área del derecho]", "[nombre del caso o partes]", "[tecnología/industria implicada]", "[tipo de acción]", "[tribunal o jurisdicción]"]
section: "jurisprudencia"
category: "analisis-juridico"
author: "Ricardo Scarpa"
slug: "[kebab-case-con-keywords-del-caso]"
readingTime: "[X min]"
---
```

**En inglés:**
```mdx
---
title: "[Short case name]: [Central legal issue in 6-10 words]"
description: "[1-2 sentences. What case, what legal question, current status. Max. 160 characters]"
date: "[YYYY-MM-DD]"
tags: ["[area of law]", "[case name or parties]", "[technology/industry]", "[type of action]", "[court or jurisdiction]"]
section: "jurisprudencia"
category: "analisis-juridico"
author: "Ricardo Scarpa"
slug: "[kebab-case-with-case-keywords]"
readingTime: "[X min]"
---
```

**Reglas del frontmatter:**
- `section` siempre `"jurisprudencia"` para análisis de casos
- `author` siempre `"Ricardo Scarpa"`
- `tags` máximo 5; incluir siempre el nombre del caso o partes principales
- `slug` con keywords del caso, nombre de partes y área del derecho
- `description` debe responder: qué caso + qué cuestión jurídica + estado actual

---

## Paso 6: Redactar el cuerpo del MDX

### Estructura obligatoria del documento

```
# [Mismo título que el frontmatter]

[Párrafo de introducción — 80-120 palabras con keyword principal]

## Ficha del Caso  ← tabla con datos procesales

## [H2 doctrinal 1: contexto y relevancia]

## [H2 doctrinal 2: posiciones de las partes y argumentos clave]

## [H2 doctrinal 3: hitos procesales y decisiones del tribunal]

## [H2 doctrinal 4: estado actual y perspectivas]

## Conclusiones y Perspectivas Prácticas  ← bullets accionables

---
*Fuentes consultadas*
```

### Ficha del caso (tabla)

| Campo | Detalle |
|-------|---------|
| **Nombre oficial** | [case_name completo] |
| **Tribunal** | [court + distrito/ciudad] |
| **Número de expediente** | [docket_number] |
| **Fecha de presentación** | [date_filed] |
| **Estado** | Activo / Terminado ([fecha si aplica]) |
| **Juez asignado** | [nombre y cargo] |
| **Causa de acción** | [causa principal] |
| **Partes** | [Demandante(s)] **v.** [Demandado(s)] |
| **MDL** | [Si aplica: número y nombre del MDL] |

### Cronología de hitos procesales

Integrada dentro del H2 correspondiente. Presenta entre 8 y 15 hitos en formato:

**[Fecha]** — **[Tipo de acto procesal]**
> Significado jurídico del acto: no solo el título del documento, sino su relevancia procesal y su impacto en el desarrollo del caso.

Hitos que siempre deben figurar si han ocurrido:
- Complaint (demanda inicial)
- Motions to dismiss y su resolución
- Órdenes de discovery relevantes y e-discovery disputes
- Summary judgment motions y resoluciones
- Preservation orders
- Vistas orales
- Sentencias parciales o definitivas
- Apelaciones
- Consolidación en MDL
- Settlement o acuerdo extrajudicial

### Títulos de H2 doctrinales

Los H2 deben ser **temáticos y doctrinales**, nunca etiquetas genéricas. Ejemplos:

✅ `## El entrenamiento de LLMs como uso transformativo: los límites del fair use`
✅ `## La preservation order sobre logs de IA: privacidad vs. obligaciones probatorias`
✅ `## Responsabilidad contributiva y directa en sistemas de IA generativa`

❌ `## Contexto del caso`
❌ `## Análisis jurídico`
❌ `## Estado actual`

### Cuerpo académico

Extensión: **500-800 palabras** en prosa académica continua. Sin listas en el cuerpo salvo las conclusiones finales. Debe cubrir:

1. **Contexto y relevancia**: por qué importa este caso, qué cuestiones de derecho plantea, qué sector del ordenamiento jurídico afecta
2. **Posiciones de las partes**: argumentos centrales del demandante y demandado, teorías jurídicas novedosas o controvertidas
3. **Desarrollos procesales significativos**: decisiones interlocutorias clave, su razonamiento y sus efectos sobre el litigio
4. **Estado actual y perspectivas**: fase procesal, próximos pasos previsibles, precedentes en juego
5. **Impacto potencial**: consecuencias para la jurisprudencia, la industria o la política pública

### Conclusiones

`## Conclusiones y Perspectivas Prácticas` (ES) o `## Conclusions and Practical Outlook` (EN):
- 4-6 bullets concretos y accionables

No incluir CTA de contacto ni llamadas a la acción comerciales. El blog es de divulgación, no de captación de servicios.

---

## Paso 7: Guardar y entregar el archivo

1. Guardar en `/mnt/user-data/outputs/[slug].mdx`
2. Llamar a `present_files` con la ruta del archivo
3. Mostrar en el chat el bloque de publicación PowerShell:

```powershell
cd C:\Proyectos\derecho-artificial
mkdir "content\jurisprudencia\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[SLUG].mdx" "content\jurisprudencia\[SLUG]\index.mdx"
node scripts/update-glosario.cjs
git add .
git commit -m "feat(jurisprudencia): [nombre corto del caso en minúsculas]"
git push
```

URL resultante: `https://www.derechoartificial.com/jurisprudencia/[SLUG]`

---

## Consideraciones de calidad

- **Precisión ante todo**: Si no puedes verificar un hito, indícalo como pendiente de verificación.
- **Normas ortotipográficas**: Latinismos en cursiva; en español, aplicar normas de puntuación y tildes del español jurídico formal; en inglés, seguir las convenciones del inglés jurídico federal estadounidense.
- **Neutralidad**: Presentar los argumentos de ambas partes de forma equilibrada.
- **Actualidad**: Priorizar información de los últimos 6 meses para el estado actual.
- **MDL**: Si el caso está consolidado en un MDL, identificar la causa madre y describir la posición del caso dentro del MDL.
- **Jurisdicción**: Este skill cubre principalmente tribunales federales de EE.UU. Para casos estatales o de otras jurisdicciones, adaptar la terminología procesal.

## Errores comunes a evitar

- No confundir el docket number (número de expediente oficial, ej. `1:23-cv-11195`) con el docket ID interno de CourtListener (número entero, ej. `68117049`).
- No asumir que el caso está terminado si no aparece `date_terminated`.
- No inventar entradas del docket. Si los datos son insuficientes, indicarlo explícitamente.
- No usar H2 genéricos. Cada caso tiene sus propias cuestiones jurídicas; los títulos deben reflejarlas.
- En inglés, no traducir términos procesales que tienen equivalente establecido: *discovery*, *deposition*, *motion to dismiss*, *summary judgment*, *en banc*, *certiorari*.
