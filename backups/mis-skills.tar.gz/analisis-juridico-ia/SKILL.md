---
name: analisis-juridico-ia
description: "Redacción de análisis jurídicos profesionales sobre inteligencia artificial siguiendo los estándares de Harvard Law School. Usar cuando el usuario solicite: (1) Crear memorandos jurídicos sobre cuestiones de IA, (2) Analizar normativa de IA (RGPD, Reglamento de IA, LOPDGDD), (3) Aplicar metodología IRAC a problemas jurídicos de IA, (4) Redactar análisis doctrinales o artículos sobre derecho e IA, (5) Evaluar conformidad legal de sistemas de IA, (6) Analizar jurisprudencia sobre IA y protección de datos, o (7) Cualquier trabajo de análisis jurídico relacionado con inteligencia artificial que requiera rigor académico y profesional."
---

# Análisis Jurídico de IA - Estándares Harvard

## Descripción General

Este skill proporciona guías y metodologías para la redacción de análisis jurídicos profesionales sobre inteligencia artificial, siguiendo los estándares académicos de Harvard Law School. Incluye:

- **Metodología IRAC** (Issue, Rule, Application, Conclusion) para estructurar argumentaciones jurídicas
- **Formato de memorandos Harvard** para documentos jurídicos profesionales
- **Sistema de citación** adaptado del Bluebook al contexto jurídico español y europeo
- **Marco normativo de referencia** sobre IA, protección de datos y regulación tecnológica

## Corrección Ortográfica y Estilo Académico

**Todo texto producido debe superar un estándar de corrección académico de nivel universitario superior.** Esto no es revisión básica de tipografías: es control activo de calidad lingüística y jurídica.

### Normas ortotipográficas obligatorias (español jurídico)

**Tildes y acentuación:**
- Tildes diacríticas: `más/mas`, `sólo/solo` (cuando hay ambigüedad), `éste/este`, `aún/aun`
- Interrogativas y exclamativas indirectas llevan tilde: `cómo`, `qué`, `cuándo`, `dónde`, `quién`
- Latinismos y extranjerismos no adaptados van en cursiva: *ratio legis*, *prima facie*, *ex ante*, *per se*

**Puntuación en textos jurídicos:**
- Coma antes de conjunciones adversativas: `..., sin embargo,`; `..., no obstante,`
- Punto y coma para separar elementos complejos en enumeraciones
- Dos puntos antes de enumeraciones formales y citas normativas directas
- Nunca coma entre sujeto y predicado

**Uso de mayúsculas:**
- Instituciones: `el Tribunal de Justicia de la Unión Europea`, `la Agencia Española de Protección de Datos`
- Normas: `el Reglamento General de Protección de Datos`, `el Reglamento de Inteligencia Artificial`
- Abreviaturas de normas ya definidas: RGPD, RIA, LOPDGDD (en versalitas si el sistema lo permite)
- No mayúscula en cargos genéricos: `el juez`, `el responsable del tratamiento`

**Números y referencias normativas:**
- Artículos: `artículo 6, apartado 1, letra b)` — nunca `Art. 6.1.b)` en el cuerpo del texto (sí en notas al pie)
- Ordinales: `primer`, `segundo` (no `1.°`, `2.°` en prosa corrida)
- Años: `2024`, nunca `el año 2024` salvo por énfasis

### Control de estilo académico-jurídico

**Errores frecuentes que hay que evitar activamente:**

| Error | Corrección |
|-------|-----------|
| "a nivel de" | "en el ámbito de" / "en materia de" |
| "en base a" | "sobre la base de" / "con arreglo a" |
| "de cara a" | "con vistas a" / "para" |
| "contemplar" (prever en norma) | "prever", "establecer", "disponer" |
| "implementar" (sin anglicismo) | "aplicar", "ejecutar", "poner en práctica" |
| "impacto" como sinónimo de "efecto" | reservar "impacto" para consecuencias graves |
| Gerundio de posterioridad | "El tribunal dictó sentencia, **condenando** al…" → "…y **condenó** al…" |
| Pasiva refleja ambigua | reformular en activa cuando el agente es relevante |

**Coherencia terminológica:**
- Fijar el término técnico en la primera aparición y mantenerlo: si se usa "responsable del tratamiento", no alternar con "controlador de datos"
- Las siglas se definen la primera vez: `Reglamento General de Protección de Datos (en adelante, RGPD)`
- No usar sinónimos estilísticos para conceptos jurídicos precisos: `datos personales` no es intercambiable con `información personal`

### Revisión ortográfica como paso obligatorio

Antes de cerrar el archivo MDX, ejecutar mentalmente este protocolo:
1. **Latinismos** — ¿están todos en cursiva?
2. **Tildes diacríticas** — revisar `más`, `sí`, `él`, `tú`, `mí`, `sé`, `dé`, `té`
3. **Gerundios** — ¿alguno expresa posterioridad o es especificativo de cosa?
4. **"En base a"** — sustituir sistemáticamente
5. **Coherencia de siglas** — ¿todas definidas en primera aparición?
6. **Mayúsculas institucionales** — ¿uniformes a lo largo del documento?

---

## Formato de Salida: MDX Optimizado para SEO

**TODOS los análisis jurídicos deben entregarse como archivos `.mdx`** guardados en `/mnt/user-data/outputs/`. Nunca entregues el análisis solo como texto en el chat.

### Idioma del documento

El idioma por defecto de todos los archivos `.mdx` es el **español formal**. Si el usuario solicita explícitamente que el resultado sea en inglés, el documento se redactará íntegramente en **inglés formal académico-jurídico** (*formal legal English*).

En ese caso, las normas de corrección ortográfica académica se aplican al inglés:
- Seguir las convenciones del inglés jurídico internacional (preferencia por el estilo británico salvo que la jurisdicción sea estadounidense)
- Latinismos en cursiva igualmente: *prima facie*, *ratio legis*, *inter alia*
- Uso correcto de *shall* vs. *must* vs. *may* en contexto normativo
- Sin calcos del español: no *"the norm contemplates"* sino *"the provision establishes"*; no *"in base to"* sino *"on the basis of"*
- Citas normativas en el idioma oficial de la norma (las normas UE se citan en su versión inglesa oficial)

El `slug` y los `tags` del frontmatter también se escriben en inglés cuando el documento es en inglés.

---

### Estructura obligatoria del frontmatter MDX

Todo archivo `.mdx` debe comenzar con este bloque de metadatos:

```mdx
---
title: "[Título del análisis — incluir término jurídico clave + IA]"
description: "[1-2 frases. Responde: qué analiza, qué norma aplica, qué concluye. Máx. 160 caracteres para meta description]"
date: "[YYYY-MM-DD]"
tags: ["Reglamento IA", "RGPD", "LOPDGDD", "alto riesgo", ...] # máx. 5 tags relevantes
section: "jurisprudencia" # | "normativa" | "firma-scarpa" | "etica-ia" | "propiedad-intelectual-ia" | "ia-global" | "guias"
category: "analisis-juridico" | "conformidad" | "memorando" | "articulo-doctrinal"
author: "Ricardo Scarpa"
slug: "[url-friendly-kebab-case-con-keywords]"
readingTime: "[X min]" # aproximado según extensión
# pdf: "/fuentes/Nombre_Archivo.pdf" # descomentar si hay documento fuente adjunto
---
```

> **Regla de `section`:** Este campo es **obligatorio** y determina dónde aparece el post en el sitio. Usar siempre uno de los valores permitidos. Si el análisis es jurisprudencia → `"jurisprudencia"`. Si es normativa → `"normativa"`. Si es un informe de la firma → `"firma-scarpa"`. En caso de duda, preguntar al usuario.
>
> **Regla de `pdf`:** Si el usuario ha proporcionado un PDF fuente (sentencia, norma, informe), incluir la línea `pdf` descomentada con la ruta `/fuentes/NombreArchivo.pdf`. Si no hay PDF, dejar la línea comentada o eliminarla.

### Reglas SEO para el cuerpo del documento

**H1 (título principal):**
- Solo uno por documento
- Debe incluir la keyword principal (ej. "Reglamento de Inteligencia Artificial", "RGPD y sistemas de IA")
- Formato: `# Título Principal con Keyword`

**H2 y H3 (estructura del artículo doctrinal):**
- Los H2 deben ser títulos temáticos propios del artículo, **nunca etiquetas IRAC**: no escribas `## Cuestión Jurídica` ni `## Marco Normativo Aplicable` como fórmula fija
- Ejemplos de títulos doctrinales: `## La supervisión humana como requisito de validez`, `## Bases jurídicas para el tratamiento en sistemas generativos`, `## Responsabilidad civil y sistemas de alto riesgo`
- Los H3 profundizan dentro de cada sección temática
- Incluir keywords secundarias de forma natural en los headings

**Párrafo de introducción (primeros 150 palabras):**
- Debe contener la keyword principal
- Responde: qué problema jurídico plantea, qué norma aplica, qué concluye brevemente
- Es lo que Google indexa con mayor peso

**Llamadas internas y externas:**
- Al citar normativa, usar formato: `[Artículo 35 RGPD](https://eur-lex.europa.eu/...)` cuando sea enlace externo verificado
- Al referenciar otros análisis del blog, usar rutas relativas: `[análisis sobre decisiones automatizadas](/analisis/decisiones-automatizadas)`

**Conclusión con CTA (Call to Action):**
- Cerrar siempre con una sección `## Conclusiones y Recomendaciones Prácticas`
- Incluir 3-5 bullet points con takeaways concretos
- Opcionalmente añadir: `> **¿Necesitas un análisis personalizado?** [Contacta aquí](/contacto)`

### Plantilla MDX base (artículo doctrinal)

```mdx
---
title: ""
description: ""
date: ""
tags: []
section: "" # jurisprudencia | normativa | firma-scarpa | etica-ia | propiedad-intelectual-ia | ia-global | guias
category: ""
author: "Ricardo Scarpa"
slug: ""
readingTime: ""
# pdf: "/fuentes/Nombre_Archivo.pdf"
---

# [Título con keyword principal]

[Párrafo introductorio de 100-150 palabras. Presenta el problema jurídico con su contexto, enuncia la norma o normas en juego y anticipa la tesis del artículo. Debe contener la keyword principal.]

## [Sección temática 1 — plantea el problema o delimita el objeto de análisis]

[Desarrollo en prosa. Aquí se identifica internamente el Issue y se contextualiza, pero sin nombrarlo así. Ej: "La cuestión que subyace a este análisis...", "El debate doctrinal se centra en..."]

## [Sección temática 2 — el marco jurídico aplicable, integrado en el argumento]

[Exposición del régimen normativo relevante entretejida con el análisis. No es un listado de normas: es la Rule integrada en el discurso. Ej: "El artículo 22 del RGPD establece... Esta previsión debe interpretarse a la luz de..."]

### [Subsección si hay varias normas o dimensiones]

## [Sección temática 3 — el análisis aplicado al caso o supuesto]

[La Application: subsunción de hechos en normas, ponderación, comparación con precedentes. Redactado como argumentación doctrinal, no como checklist.]

## [Sección temática 4 — posiciones doctrinales, tensiones o excepciones]

[Consideración de interpretaciones alternativas, posiciones de la AEPD, jurisprudencia divergente. Enriquece el análisis sin etiquetar el método.]

## Conclusiones

[La Conclusion: respuesta a la cuestión planteada, consecuencias jurídicas, recomendaciones prácticas. Puede incluir bullets para los takeaways operativos.]

- **[Punto clave 1]:** ...
- **[Punto clave 2]:** ...
- **[Punto clave 3]:** ...
```

### Longitud óptima por tipo de documento

| Tipo | Palabras objetivo | Headings mínimos |
|------|------------------|-----------------|
| Brief ejecutivo | 600–900 | 4 H2 |
| Análisis estándar | 1.200–2.000 | 6 H2 + H3s |
| Memorando formal | 2.000–3.500 | 8 H2 + H3s |
| Artículo doctrinal | 2.500–4.000 | 10+ H2 + H3s |

---

## Flujo de Trabajo Principal

Cuando recibas una solicitud de análisis jurídico sobre IA, sigue este proceso:

### 1. Identificación del tipo de documento

Determina qué tipo de análisis se requiere:

**¿Es un memorando jurídico formal?**
→ Usar formato completo de memorando Harvard (ver referencias/formato_memo_harvard.md)
→ Incluir: Header, Question Presented, Brief Answer, Facts, Discussion, Conclusion

**¿Es un análisis académico o artículo?**
→ Aplicar IRAC pero sin formato de memo estricto
→ Enfoque más expositivo y doctrinal

**¿Es un brief ejecutivo o resumen?**
→ IRAC condensado
→ Énfasis en conclusiones prácticas

**¿Es una evaluación de conformidad?**
→ Estructura checklist + IRAC por cada requisito
→ Conclusiones operativas

### 2. Preparación del análisis

**Paso 2.1: Identificar las cuestiones jurídicas (Issues)**

Formula preguntas jurídicas específicas y precisas:
- ¿Qué norma se aplica?
- ¿Qué derecho está en juego?
- ¿Qué requisitos deben cumplirse?

**Paso 2.2: Determinar la jurisdicción aplicable**

Antes de identificar normativa, determinar el ámbito territorial del análisis:

**¿La jurisdicción es española o europea?**
→ Aplicar el marco por defecto: RGPD, Reglamento de Inteligencia Artificial, LOPDGDD, jurisprudencia del TJUE y tribunales españoles, doctrina de la AEPD y el CEPD
→ Consultar referencias/marco_normativo.md

**¿La jurisdicción es otra (EE.UU., Reino Unido, Latinoamérica, Asia-Pacífico, etc.)?**
→ Sustituir íntegramente el marco normativo de referencia por el de la jurisdicción indicada
→ Identificar: la legislación sectorial aplicable (ej. CCPA, AI Act equivalente, ley de protección de datos local), la jurisprudencia de los tribunales competentes y la doctrina de la autoridad supervisora correspondiente
→ No mezclar normativa de distintas jurisdicciones salvo que el análisis lo requiera expresamente (ej. transferencias internacionales, aplicación extraterritorial del RGPD)
→ Si la jurisdicción tiene un marco regulatorio de IA incipiente o inexistente, indicarlo expresamente y analizar bajo el derecho común aplicable (responsabilidad civil, protección de datos general, competencia desleal, etc.)

**¿El análisis es multijurisdiccional?**
→ Estructurar el artículo con secciones por jurisdicción o por eje temático comparado
→ Señalar expresamente las convergencias y divergencias normativas relevantes

**Paso 2.3: Planificar la estructura IRAC**

Según la complejidad:
- **Análisis simple:** IRAC lineal con un solo issue
- **Análisis medio:** IRAC con 2-4 issues relacionados
- **Análisis complejo:** Multi-level IRAC con sub-issues

### 3. Redacción del documento

**Paso 3.0: Preparar el archivo MDX**

Antes de escribir el contenido:
1. Define el `slug` (ej. `rgpd-scoring-crediticio-eipd`) — será el nombre del archivo
2. Determina el valor de `section` según la sección del sitio donde irá el post
3. Completa el frontmatter con title, description (≤160 chars), tags, section, category y author: "Ricardo Scarpa"
4. Si el usuario ha proporcionado un PDF fuente, incluir `pdf: "/fuentes/NombreArchivo.pdf"`
5. Crea el archivo en `/mnt/user-data/outputs/[slug].mdx`
4. Escribe el contenido siguiendo la plantilla MDX y las reglas SEO definidas arriba

**Paso 3.1: Consultar metodología IRAC**

SIEMPRE leer referencias/metodologia_irac.md antes de empezar a escribir para:
- Estructurar correctamente cada sección
- Aplicar técnicas de subsunción normativa
- Evitar errores comunes
- Ajustar profundidad del análisis

**Paso 3.2: Consultar formato de memo (si aplica)**

Si es un memorando formal, leer referencias/formato_memo_harvard.md para:
- Crear encabezado correcto
- Redactar Question Presented efectiva
- Estructurar Facts objetivamente
- Organizar Discussion con headings apropiados
- Formatear según estándares tipográficos

**Paso 3.3: Redactar con citación apropiada**

Consultar referencias/sistema_citacion.md para:
- Citar normativa europea y española correctamente
- Referenciar jurisprudencia del TJUE y tribunales españoles
- Citar guías de la AEPD y dictámenes del CEPD
- Referenciar doctrina científica
- Aplicar formato Bluebook adaptado

### 4. El método IRAC como arquitectura invisible

**El IRAC estructura el pensamiento jurídico, no el texto visible.** El artículo doctrinal resultante nunca debe mostrar las etiquetas Issue, Rule, Application, Conclusion. El lector experimenta un argumento fluido; el método opera por debajo.

**Equivalencias IRAC → prosa doctrinal:**

| Fase IRAC | Lo que hace en el artículo |
|-----------|---------------------------|
| **Issue** | Se formula como pregunta retórica o como delimitación del objeto de estudio en la introducción o primera sección. Ej: *"¿Puede considerarse que un modelo generativo adopta decisiones en el sentido del artículo 22 RGPD? Esta es la cuestión central que..."* |
| **Rule** | Se expone integrada en el argumento, con voz analítica: *"El legislador europeo optó por... Esta elección normativa responde a..."* — no como inventario de preceptos |
| **Application** | Es el núcleo analítico del artículo: subsunción, ponderación, comparación con precedentes, redactada como argumentación encadenada con conectores lógicos |
| **Conclusion** | Se anticipa parcialmente en la introducción (tesis) y se desarrolla en la sección final, con implicaciones prácticas |

**Conectores doctrinales para transiciones naturales:**
- Issue → Rule: *"Para resolver esta cuestión conviene examinar..."*, *"El régimen jurídico aplicable parte de..."*
- Rule → Application: *"Trasladando este marco al supuesto analizado..."*, *"A la luz de lo anterior, cabe afirmar que..."*
- Application → Conclusion: *"De cuanto antecede se desprende..."*, *"En definitiva..."*, *"La conclusión que se impone es..."*

**Lo que nunca debe aparecer en el texto final:**
- Encabezados tipo `## Issue`, `## Rule`, `## Application`, `## Conclusion`
- Frases como "en la fase de Application del análisis IRAC"
- Numeración automática tipo `1. Issue — 2. Rule — 3. Application`
- Referencias al método en el cuerpo del artículo


### 5. Revisión final

**Checklist jurídico:**
- [ ] Todas las afirmaciones jurídicas están citadas
- [ ] El argumento responde a la cuestión planteada en la introducción
- [ ] Las conclusiones derivan lógicamente del desarrollo
- [ ] El formato de citación es consistente
- [ ] El lenguaje es preciso y técnico-jurídico
- [ ] Se han considerado contraargumentos o posiciones doctrinales alternativas
- [ ] Las referencias normativas son vigentes y correctamente citadas

**Checklist IRAC invisible:**
- [ ] No aparece ninguna etiqueta IRAC en el texto (Issue, Rule, Application, Conclusion)
- [ ] La cuestión jurídica central se plantea en prosa en la introducción o primera sección
- [ ] El marco normativo se expone integrado en el argumento, no como lista de preceptos
- [ ] La subsunción está redactada como argumentación encadenada
- [ ] Las conclusiones incluyen consecuencias jurídicas y recomendaciones prácticas

**Checklist ortográfico académico:**
- [ ] Latinismos y extranjerismos en cursiva (*prima facie*, *ratio legis*, *software*)
- [ ] Tildes diacríticas correctas (`más`, `sí`, `él`, `aún` cuando corresponde)
- [ ] Sin "en base a" — sustituido por "sobre la base de" o "con arreglo a"
- [ ] Sin gerundios de posterioridad ni especificativos de cosa
- [ ] Siglas definidas en primera aparición
- [ ] Mayúsculas institucionales uniformes
- [ ] Terminología jurídica coherente (sin variaciones estilísticas de conceptos técnicos)

**Checklist MDX/SEO:**
- [ ] El frontmatter está completo (title, description, date, tags, slug)
- [ ] La `description` tiene ≤160 caracteres
- [ ] El H1 contiene la keyword principal
- [ ] Los primeros 150 palabras contienen la keyword principal
- [ ] Los H2 son títulos temáticos doctrinales (no etiquetas IRAC)
- [ ] La longitud es apropiada para el tipo de documento (ver tabla)
- [ ] La sección final es `## Conclusiones` con tesis clara y bullets operativos
- [ ] El archivo está guardado en `/mnt/user-data/outputs/[slug].mdx`


## Tipos de Análisis Comunes

### Análisis de conformidad RGPD

**Issues típicos:**
- ¿Existe base jurídica válida? (Art. 6 RGPD)
- ¿Se cumplen los principios de tratamiento? (Art. 5 RGPD)
- ¿Se requiere EIPD? (Art. 35 RGPD)
- ¿Se respetan derechos de los interesados? (Arts. 12-23 RGPD)
- ¿Hay transferencias internacionales? (Cap. V RGPD)

**Enfoque:**
1. Identificar ciclo de vida del sistema (diseño, entrenamiento, despliegue)
2. Analizar cada fase según RGPD
3. Evaluar medidas técnicas y organizativas
4. Determinar roles (responsable/encargado/corresponsable)

### Análisis de sistemas de IA de alto riesgo

**Issues típicos:**
- ¿El sistema califica como alto riesgo? (Art. 6 + Anexo III RIA)
- ¿Cumple requisitos del proveedor? (Arts. 9-15 RIA)
- ¿Requiere evaluación de conformidad? (Arts. 43-48 RIA)
- ¿Hay supervisión humana efectiva? (Art. 14 RIA)

**Enfoque:**
1. Clasificación del sistema según RIA
2. Análisis de obligaciones específicas por categoría
3. Interacción RIA-RGPD
4. Evaluación de gobernanza de datos

### Análisis de sistemas prohibidos

**Issues típicos:**
- ¿El sistema cae en categoría prohibida? (Art. 5 RIA)
- ¿Aplican excepciones de seguridad pública?
- ¿Qué competencias tiene la AEPD para supervisar?

**Enfoque:**
1. Subsunción en supuestos del Art. 5 RIA
2. Análisis de posibles excepciones
3. Evaluación de riesgo sancionador
4. Recomendaciones de mitigación

### Análisis de decisiones automatizadas

**Issues típicos:**
- ¿Aplica el Art. 22 RGPD?
- ¿Hay supervisión humana significativa?
- ¿Se garantiza transparencia sobre la lógica?
- ¿Existen medidas de salvaguarda?

**Enfoque:**
1. Determinar si es "decisión únicamente automatizada"
2. Evaluar excepciones (consentimiento, contrato, ley)
3. Analizar medidas de protección implementadas
4. Revisar derechos de oposición e intervención humana

## Voz y Estilo de Escritura

**Antes de empezar a escribir, piensa brevemente en cómo lo haría una persona real con experiencia jurídica y académica en el tema.** No como una máquina generando texto estructurado, sino como un jurista que lleva años trabajando con esta materia y tiene cosas concretas que decir.

### Escritura con voz humana — reglas activas

**Variación real en la longitud de las oraciones.** No todas las frases pueden tener la misma extensión. Algunas son cortas. Otras se extienden un poco más cuando el argumento lo pide, introduciendo matices o excepciones que no caben en una frase breve. Y algunas son directamente largas, especialmente cuando se está explicando la articulación entre dos normas o la lógica de un razonamiento que no admite simplificación.

**Irregularidades naturales del lenguaje.** Un escritor humano aclara entre paréntesis cuando lo necesita (aunque a veces esa aclaración podría haberse evitado). Retoma un argumento que dejó incompleto. Reconoce una dificultad antes de resolverla. Estas pequeñas desviaciones del texto perfecto son señales de pensamiento real, no de descuido.

**Evitar estructuras demasiado simétricas.** Si tres párrafos seguidos empiezan con la misma construcción sintáctica, o si cada sección tiene exactamente dos argumentos y una conclusión, el texto suena fabricado. La simetría excesiva es el mayor indicador de escritura no humana.

**Reflexiones que surgen mientras se escribe.** Incluir ocasionalmente una observación que no estaba en el esquema inicial: una comparación que ilumina el problema desde un ángulo inesperado, una duda razonable sobre la interpretación dominante, una referencia a cómo este debate se ha planteado en otro contexto. No todo tiene que estar planificado de antemano.

**Conectores variados y no repetitivos.** No empezar todos los párrafos con "En este sentido" o "Por otro lado". Usar "Sin embargo", "Conviene recordar que", "Lo que resulta llamativo es", "Dicho esto", "No obstante", "Ahora bien", "Aquí es donde el análisis se complica". Rotar.

**Tono conversacional con sustancia.** El texto debe poder leerse en voz alta sin sonar a burocracia jurídica. Eso no significa renunciar al rigor — significa que el rigor debe expresarse con claridad, no con oscuridad deliberada.

**Matices y dudas razonables.** Cuando la norma es ambigua, decirlo. Cuando la jurisprudencia no ha resuelto la cuestión, señalarlo. Cuando hay dos interpretaciones plausibles, exponerlas antes de decantarse por una. La certeza artificial es tan poco creíble como la vaguedad deliberada.

**Sin listas donde cabe prosa.** Las listas de bullets interrumpen el flujo del razonamiento jurídico. Reservarlas para los takeaways finales o para enumeraciones que genuinamente no tienen otra forma. El cuerpo del análisis se escribe en párrafos.

---

## Consideraciones de Estilo y Tono

### Lenguaje técnico-jurídico
Precisión terminológica, uso correcto de conceptos jurídicos, evitar ambigüedades, claridad expositiva. La precisión y la legibilidad no son objetivos contradictorios.

### Objetividad analítica
Análisis neutral y equilibrado, consideración de múltiples interpretaciones, reconocimiento de incertidumbres, fundamentación rigurosa.

### Estructura argumentativa
Coherencia lógica, transiciones claras entre secciones, uso de conectores argumentativos variados, párrafos bien estructurados pero no mecánicos.

### Rigor académico
Citación exhaustiva de fuentes, referencias a doctrina autorizada, consideración de jurisprudencia relevante, actualización normativa.

## Recursos Disponibles

Este skill incluye archivos de referencia detallados que deben consultarse según sea necesario:

### references/metodologia_irac.md
**Cuándo consultar:** SIEMPRE antes de estructurar cualquier análisis jurídico

Contiene:
- Descripción detallada de cada componente IRAC
- Técnicas de subsunción normativa
- Estructuras para análisis multi-nivel
- Errores comunes a evitar
- Ejemplos aplicados a IA

### references/formato_memo_harvard.md
**Cuándo consultar:** Al redactar memorandos jurídicos formales

Contiene:
- Estructura completa del memorando
- Formato de encabezado
- Cómo redactar Question Presented
- Cómo redactar Brief Answer
- Organización de la sección Discussion
- Estándares tipográficos y de formato
- Checklist de calidad

### references/sistema_citacion.md
**Cuándo consultar:** Al citar cualquier fuente normativa, jurisprudencial o doctrinal

Contiene:
- Formato Bluebook adaptado
- Citación de normativa europea y española
- Citación de jurisprudencia TJUE y tribunales españoles
- Citación de guías AEPD y dictámenes CEPD
- Citación de doctrina científica
- Citación de fuentes web y blogs especializados
- Uso de abreviaturas
- Formato de citas en texto vs. notas al pie

### references/marco_normativo.md
**Cuándo consultar:** Para identificar normativa aplicable o verificar referencias legales

Contiene:
- Reglamento de IA (estructura, plazos, obligaciones)
- RGPD (principios, bases jurídicas, derechos)
- LOPDGDD (aspectos específicos españoles)
- Jurisprudencia clave del TJUE
- Guías de la AEPD sobre IA
- Dictámenes del CEPD
- Soft law internacional
- Propuestas legislativas en curso

## Ejemplos de Uso

### Ejemplo 1: Artículo doctrinal sobre EIPD en scoring crediticio

**Usuario:** "Necesito un análisis sobre si un sistema de IA para scoring crediticio requiere EIPD bajo el RGPD"

**Proceso interno (no visible en el output):**
1. Issue: ¿Obliga el artículo 35 RGPD a realizar una EIPD para este sistema?
2. Rule: Art. 35 RGPD + criterios CEPD + Lista de la AEPD + Art. 22 RGPD
3. Application: El scoring crediticio automatizado procesa datos a escala, genera perfiles y produce efectos jurídicos significativos → tres criterios del art. 35.3 concurren
4. Conclusion: La EIPD es obligatoria; recomendaciones de implementación

**Output MDX (título de secciones doctrinales, no IRAC):**
- `## El scoring crediticio automatizado como supuesto de tratamiento de alto riesgo`
- `## El régimen de la evaluación de impacto en el RGPD y su aplicación a sistemas de IA`
- `## Concurrencia de criterios de riesgo en los sistemas de puntuación crediticia`
- `## Obligatoriedad de la EIPD: consecuencias y hoja de ruta`
- `## Conclusiones`

### Ejemplo 2: Análisis de conformidad de modelo generativo

**Usuario:** "Analiza si ChatGPT cumple el RGPD en su fase de entrenamiento"

**Proceso interno:** Multi-IRAC con cuatro issues (base jurídica, minimización, categorías especiales, derechos)

**Output MDX (titulación doctrinal):**
- `## El entrenamiento de modelos de lenguaje como operación de tratamiento masivo`
- `## La base jurídica del interés legítimo y sus límites en el raspado web a escala`
- `## Categorías especiales de datos y el principio de minimización en conjuntos de entrenamiento`
- `## El ejercicio de derechos por los interesados frente a modelos ya entrenados`
- `## Conclusiones`

### Ejemplo 3: Brief ejecutivo sobre reconocimiento facial

**Usuario:** "Resume en 2 páginas si un sistema de reconocimiento facial en tiempo real está prohibido"

**Proceso interno:** IRAC condensado — Issue único, Rule central (art. 5 RIA), Application rápida, Conclusion operativa

**Output MDX (400-600 palabras, 3-4 H2 temáticos):**
- `## La identificación biométrica remota en tiempo real como práctica prohibida`
- `## Excepciones al régimen de prohibición y condiciones de aplicabilidad`
- `## Conclusiones y evaluación del riesgo regulatorio`


## Ajustes Según el Usuario

### Para análisis académicos
- Mayor profundidad doctrinal
- Referencias bibliográficas extensas
- Consideración de posiciones divergentes
- Propuestas de lege ferenda

### Para análisis profesionales/corporativos
- Enfoque práctico y operativo
- Énfasis en riesgos y recomendaciones
- Conclusiones ejecutivas claras
- Cronogramas de implementación

### Para artículos de blog (Derecho Artificial)
- Tono más accesible pero riguroso
- Estructura clara con headings
- Ejemplos concretos
- Enlaces a fuentes
- Conclusiones con takeaways prácticos

## Notas Importantes

9. **Jurisdicción aplicable:** El marco normativo por defecto de este skill es el español y europeo. Si el análisis corresponde a otra jurisdicción, todo el andamiaje normativo, jurisprudencial y doctrinal debe sustituirse por el de esa jurisdicción: no se cita el RGPD si la ley aplicable es la CCPA californiana, ni se referencia la AEPD si la autoridad competente es la ICO británica o la FTC estadounidense. En jurisdicciones con regulación de IA poco desarrollada, el análisis debe identificar expresamente ese vacío y razonar desde el derecho común aplicable.

2. **Interacción normativa:** RIA y RGPD se aplican conjuntamente. El cumplimiento de uno no exime del otro.

3. **Contexto español:** Considerar tanto normativa UE como desarrollo español (LOPDGDD, anteproyecto ley IA).

4. **Autoridades competentes:** AEPD tiene competencias tanto en RGPD como en supervisión de IA que trate datos personales.

5. **Soft law relevante:** Las guías de la AEPD y dictámenes del CEPD, aunque no vinculantes, son altamente influyentes en la práctica.

6. **Especificidades técnicas de IA:** Comprender conceptos como entrenamiento, inferencia, modelos fundacionales, fine-tuning, es esencial para análisis jurídico preciso.

7. **Ciclo de vida:** Analizar separadamente las fases de diseño, entrenamiento, validación, despliegue y uso del sistema IA.

8. **Roles:** Distinguir claramente entre proveedor, implementador, usuario, responsable del tratamiento y encargado del tratamiento.
