---
name: hook-generico-pdf
description: "Genera un artículo MDX hook optimizado para SEO a partir de cualquier PDF (sentencias, normativa, informes, resoluciones, etc.) que actúa como gancho editorial para que el lector descargue el documento completo. Aplicable a cualquier documento jurídico, técnico o administrativo. Usar cuando el usuario suba un PDF y pida un artículo, hook, post o MDX para publicar con enlace de descarga. Activar también con expresiones como 'necesito un gancho para este PDF', 'convertir este documento en post', 'hacer un artículo sobre esto', 'publicar esto con descarga', o cualquier variante que combine un documento con la necesidad de crear contenido editorial de enganche."
---

# Hook Genérico para PDF — MDX desde cualquier documento

## Contexto

Los hooks genéricos son artículos editoriales que actúan como **punto de entrada editorial** para que el lector descargue, consulte o se interese en el documento original (sentencia, normativa, informe, resolución, caso, etc.). No son resúmenes: son piezas independientes que **seleccionan los argumentos más potentes**, crean tensión intelectual o relevancia práctica, y terminan con un CTA de descarga.

Este skill funciona con **cualquier tipo de PDF**:
- Sentencias judiciales y resoluciones
- Normativa y reglamentos
- Informes técnicos o académicos
- Casos de estudio
- Documentos administrativos
- Resoluciones de organismos reguladores
- Papers y investigaciones

El frontmatter debe ser flexible para adaptarse a diferentes secciones y contextos de derechoartificial.com.

---

## Flujo de trabajo

### Paso 1 — Leer el PDF completo

Leer el documento PDF adjunto en su totalidad antes de escribir nada. Identificar:

- **Tesis central o conclusión principal**: ¿qué sostiene, resuelve o determina el documento?
- **El dato, caso o escena más impactante**: la cifra, precedente, fallo o situación que abre los ojos
- **La relevancia práctica**: ¿por qué debería importarle esto al lector hoy?
- **La pregunta incómoda**: el dilema, la brecha legal, la incertidumbre que el documento aborda
- **Lo que el artículo NO contiene**: qué queda reservado para el PDF (para justificar la descarga)
- **Autor, institución, fecha**: para el frontmatter y contextualización
- **Tipo de documento**: sentencia, normativa, informe, resolución, etc.

### Paso 2 — Construir el frontmatter

```mdx
---
title: "[Título con keyword principal — incluir elemento clave del PDF + contexto jurídico/práctico]"
description: "[1-2 frases. Qué documento es, dato más impactante o conclusión clave. Máx. 160 caracteres]"
date: "[YYYY-MM-DD — fecha de PUBLICACIÓN en la web, hoy, no la fecha del documento]"
tags: ["[término clave 1]", "[término clave 2]", "[término clave 3]", "[término clave 4]", "[término clave 5]"]
section: "[sección-apropiada]"
category: "[categoría-apropiada]"
author: "[Autor del post — o 'Redacción' si es análisis de documento]"
slug: "[kebab-case con keywords principales]"
readingTime: "[X min — calcular: ~200 palabras/min]"
pdf: "/fuentes/[nombre-exacto-del-archivo.pdf]"
---
```

**Reglas del frontmatter:**

- `date`: **IMPORTANTE** — Es la fecha de publicación del post en derechoartificial.com (hoy), NO la fecha del documento original. Los posts se ordenan por esta fecha. Si el documento es de 2024 pero lo publicas hoy, la fecha es hoy.

- `section`: elegir según contexto:
  - `"analisis"` para sentencias, casos, resoluciones
  - `"normativa"` para leyes, reglamentos, directivas
  - `"firma-scarpa"` si es análisis de autor con informe propio
  - `"recursos"` si es documento de consulta o referencia
  - `"jurisprudencia"` si es jurisprudencia relevante
  
- `category`: elegir según tipo:
  - `"analisis-juridico"` para análisis doctrinal
  - `"jurisprudencia"` para sentencias
  - `"normativa"` para leyes y reglamentos
  - `"guia-practica"` para documentos prácticos
  - `"investigacion"` para informes y estudios

- `author`: nombre del autor del post o "Redacción" si es análisis editorial
  
- `pdf`: usar el nombre exacto del archivo PDF tal como se llama en el sistema
  
- `slug`: debe contener las keywords más relevantes del documento
  
- `tags`: máximo 5, deben incluir términos específicos del documento (nombres de leyes, sentencias, conceptos clave)

### Paso 3 — Escribir el artículo hook

**Estructura obligatoria:**

1. **Apertura con el dato, caso o escena más impactante** (no empezar con contexto genérico)
2. **2-4 secciones temáticas** con H2 que reflejen la estructura del documento o sus argumentos principales
3. **La pregunta que el lector no puede evitar** — el dilema central, la brecha legal, o la implicación práctica
4. **"Lo que viene en el documento"** — sección explícita que anticipa qué encontrará el lector sin desvela todo
5. **CTA de descarga** integrado naturalmente, en blockquote
6. **Conclusiones** en bullets accionables (5 máximo) o reflexión final sin listas

**Longitud objetivo:** 800-1.100 palabras. Suficiente para enganchar, no tanto como para sustituir el documento.

### Reglas de estilo (obligatorias)

**Voz humana con criterio:**

- Variación real en longitud de oraciones: cortas, medias y largas mezcladas
- Reflexiones que parecen surgir mientras se escribe: "Lo que más me llama la atención...", "Aquí es donde se abre la complejidad", "Y esto, en el ámbito jurídico, no es un detalle menor"
- Cuando el documento no da una respuesta definitiva, expresar esa incertidumbre con naturalidad
- Conectores variados: "Sin embargo", "Dicho esto", "Ahora bien", "Lo que resulta llamativo es", "Conviene recordar que", "Merece la pena notar", "La cuestión que se plantea"
- Sin listas en el cuerpo del texto salvo las conclusiones finales o cuando son evidentemente necesarias
- Latinismos y términos técnicos en cursiva: *prima facie*, *data controller*, *due process*, *habeas corpus*

**Adaptación según tipo de documento:**

| Tipo de documento | Tono de apertura | Enfoque principal |
|---|---|---|
| **Sentencia** | Caso concreto, fallo sorprendente o precedente | Implicación jurisprudencial, cambio de doctrina |
| **Normativa** | Obligación nueva, prohibición, cambio regulatorio | Impacto práctico, cumplimiento, riesgos |
| **Informe técnico** | Hallazgo sorprendente, dato que contrasta expectativas | Fiabilidad, metodología, replicabilidad |
| **Resolución administrativa** | Decisión inesperada, caso emblemático | Precedente administrativo, interpretación |

**SEO:**
- La keyword principal aparece en el primer párrafo
- Los H2 incluyen keywords secundarias de forma natural
- La meta description responde: qué documento + dato más potente + implicación

### Paso 4 — Entregar el archivo

Guardar el MDX en `/mnt/user-data/outputs/[slug].mdx` y presentarlo con `present_files`.

Tras el archivo, mostrar el bloque de instrucciones de publicación:

**Para publicación en derechoartificial.com:**

```powershell
cd C:\Proyectos\derecho-artificial
mkdir "content\[SECTION]\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-MDX].mdx" "content\[SECTION]\[SLUG]\index.mdx"
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-PDF].pdf" "public\fuentes\"
node scripts/update-glosario.cjs
git add .
git commit -m "feat([section]): [título corto en minúsculas]"
git push
```

**URL resultante (ejemplo):**
`https://www.derechoartificial.com/[section]/[slug]`

---

## Qué hace un buen hook (y qué lo arruina)

**Hace bien:**
- Revela inmediatamente por qué alguien debería leer/descargar el documento
- Crea tensión intelectual alrededor del argumento, fallo o conclusión central
- Deja al lector con preguntas que solo el documento completo puede responder
- Adapta el tono al tipo de documento (urgencia para normativa, análisis crítico para sentencias, sorpresa para hallazgos)
- El CTA de descarga aparece como consecuencia natural del texto, no como banner intrusivo

**Arruina el hook:**
- Empezar con contexto genérico sobre IA, Derecho o la industria
- Resumir el documento punto por punto sin criterio editorial
- Revelar las conclusiones principales antes del CTA
- Usar un tono neutro de press release o resumen ejecutivo
- Estructuras simétricas y perfectas que no suenan a persona real escribiendo
- Perder de vista la relevancia práctica: "¿y qué? ¿por qué debería importarme esto?"

---

## Ejemplos de apertura según tipo de documento

**Sentencia:**
✅ "La Audiencia Nacional acaba de romper un silencio de años sobre cómo interpretar el derecho al olvido cuando los datos están indexados por buscadores. Y lo hace de una manera que ningún abogado esperaba."

❌ "La sentencia de la Audiencia Nacional aborda el tema del derecho al olvido."

**Normativa:**
✅ "A partir del 1 de enero, cualquier empresa que procese datos biométricos tendrá que solicitar una autorización específica. El Reglamento no la prohíbe, pero la rodea de tantas exigencias que el margen de cumplimiento se reduce a casi nada."

❌ "La nueva normativa establece requisitos para el procesamiento de datos biométricos."

**Informe técnico:**
✅ "El estudio demuestra que los sistemas de IA que todavía hoy se consideran 'sesgo irreducible' tienen un margen de mejora del 34%. Esto cambia toda la conversación sobre equidad algorítmica."

❌ "El informe analiza el tema del sesgo en sistemas de IA."

**Resolución administrativa:**
✅ "La AEPD acaba de sancionar a una empresa por un motivo que parecía resuelto: considerar el seudónimo en redes como dato no identificable. Y la sanción es severa."

❌ "La AEPD ha dictado una resolución sobre protección de datos."

---

## Checklist antes de entregar

- [ ] El PDF ha sido leído completamente
- [ ] La apertura es con datos, casos o escenas, no con contexto genérico
- [ ] Los H2 reflejan argumentos del documento, no estructura estándar (marco, análisis, conclusiones)
- [ ] Hay al menos una pregunta sin respuesta dentro del hook
- [ ] El CTA de descarga está en blockquote y suena natural
- [ ] La longitud está entre 800-1.100 palabras
- [ ] El slug incluye keywords principales
- [ ] El frontmatter es válido y la ruta del PDF es correcta
- [ ] No se revelan todas las conclusiones del documento
- [ ] La voz es humana, con variación de oraciones y conexiones naturales
- [ ] El tono se adapta al tipo de documento (sentencia ≠ normativa ≠ informe)
