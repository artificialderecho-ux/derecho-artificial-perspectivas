---
name: articulo-firma-scarpa
description: "Genera un artículo largo MDX (2.000-4.000 palabras) optimizado para SEO a partir de un informe PDF, para publicar en la sección Firma Scarpa de derechoartificial.com. Usar cuando el usuario suba un PDF de informe propio y pida un artículo largo, análisis completo, post extenso, o MDX para Firma Scarpa. Activar también cuando el usuario diga 'quiero un artículo largo', 'hazlo completo', 'no quiero hook sino artículo', 'analiza esto en profundidad', 'quiero publicar esto en Firma Scarpa', o cualquier variante que combine un documento de autoría propia con la sección Firma Scarpa y busque profundidad en lugar de gancho corto. Este skill reemplaza al hook-firma-scarpa cuando el objetivo es un artículo de fondo, no un gancho de descarga."
---

# Artículo largo para Firma Scarpa — MDX desde informe PDF

## Contexto

Firma Scarpa es la sección de análisis de autor en derechoartificial.com. Este skill genera artículos largos (2.000-4.000 palabras) que son piezas independientes de posicionamiento SEO, no hooks de descarga. El artículo largo ES el producto: analiza con profundidad, desarrolla doctrina, aporta criterio propio y posiciona keywords de long-tail que un hook corto no puede capturar.

**Diferencia clave con el hook:** el artículo largo no retiene información para forzar una descarga — la agota. Su valor está en la profundidad, no en la tensión.

---

## Flujo de trabajo

### Paso 1 — Leer el PDF completo

Leer el documento PDF adjunto en su totalidad antes de escribir nada. Extraer obligatoriamente:

- **Tesis central**: ¿qué argumento sostiene el informe?
- **El dato más extremo**: cifra, plazo, porcentaje, reducción — cuanto más concreto, mejor
- **La paradoja central**: lo que "debería ser" vs. lo que realmente ocurre
- **El sujeto inesperado**: ¿quién hace algo que nadie esperaría?
- **La consecuencia directa para el lector jurista**: ¿qué cambia para un abogado concreto?
- **La pregunta que el lector ya tiene pero no se ha atrevido a formular**
- **Marco normativo y jurisprudencia citada**: para desarrollar en el cuerpo del artículo
- **Argumentos secundarios y matices**: material para las secciones de desarrollo
- **Conclusiones del informe**: para la sección final del artículo
- **Autor y fuentes**: para frontmatter y referencias

---

### Paso 2 — Titulación (integrada del skill titulacion-derechoartificial)

Antes de escribir una sola línea del artículo, resolver la titulación completa aplicando las 6 técnicas. Elegir la mejor y usarla como apertura del artículo.

#### Las 6 técnicas de gancho

**Técnica 1 — Paradoja en dos tiempos (A / B)**
Enuncia lo que "debería ser" y rómpelo en la segunda parte.
- Estructura: `[Creencia establecida]. [Hecho que la destruye].`
- Señal de uso: el artículo contradice una asunción profesional extendida.

**Técnica 2 — Cifra imposible**
Un número tan concreto o extremo que obliga a entender cómo es posible.
- Estructura: `[Cifra A] → [Cifra B]. [Magnitud sin revelar el cómo].`
- Señal de uso: el informe contiene datos numéricos que el lector no esperaría.

**Técnica 3 — Pregunta con respuesta incómoda**
Formula la pregunta que el lector tiene en mente. La respuesta es siempre contraintuitiva.
- Estructura: `[Pregunta directa]. [La norma/el tribunal] no [verbo].`
- Señal de uso: el informe expone un vacío legal o contradicción normativa.

**Técnica 4 — Verbo de acción inesperado**
El sujeto real + el verbo concreto. Sin abstracciones.
- Estructura: `[Sujeto] [verbo de acción concreto]. [Consecuencia en una línea].`
- Señal de uso: hay un actor institucional que tomó una acción sorprendente.

**Técnica 5 — Posesión inesperada (tu X tiene Y)**
Convierte lo abstracto en personal e inmediato.
- Estructura: `Tu [elemento personal] [verbo]. [Implicación directa].`
- Señal de uso: el artículo tiene consecuencias directas directas para el lector.

**Técnica 6 — Contraste geográfico o temporal**
Crea urgencia sin sensacionalismo.
- Estructura: `[Lugar A] [ya hace X] desde [fecha]. [Europa/España] [sigue debatiendo].`
- Señal de uso: el informe analiza un modelo extranjero o compara sistemas.

#### Resolver internamente antes de escribir:

```
TÍTULO SEO (55-65 caracteres, keyword-first, para frontmatter):
[...]

GANCHO EDITORIAL (H1 visible, impacto máximo, aplica la técnica elegida):
[...]

PRIMERA LÍNEA DEL ARTÍCULO (desarrolla el gancho en 2-3 frases):
[...]

TÉCNICA ELEGIDA: [número] — [justificación en una línea]
```

**Reglas absolutas de titulación:**
- Prohibido: "Análisis de...", "Estudio sobre...", "Reflexiones en torno a..."
- Prohibido: usar el nombre de la norma como sujeto sin verbo de acción
- Prohibido: adjetivos vacíos ("importante", "relevante", "interesante")
- El gancho debe funcionar sin contexto previo
- Si hay dato numérico extremo, debe aparecer en al menos una opción
- El sujeto gramatical del gancho debe ser concreto (un tribunal, un abogado, una ley, un número)

---

### Paso 3 — Construir el frontmatter

```mdx
---
title: "[Título SEO del Paso 2 — 55-65 caracteres con keyword principal]"
description: "[1-2 frases. Qué analiza + dato más impactante + conclusión clave. Máx. 160 caracteres]"
date: "[YYYY-MM-DD — fecha actual]"
tags: ["[término clave 1]", "[término clave 2]", "[término clave 3]", "[término clave 4]", "[término clave 5]"]
section: "firma-scarpa"
category: "analisis-juridico"
author: "Ricardo Scarpa"
slug: "[kebab-case con keywords principales del título SEO]"
readingTime: "[X min — calcular: ~200 palabras/min]"
pdf: "/fuentes/[nombre-exacto-del-archivo.pdf]"
---
```

**Reglas del frontmatter:**
- `section` siempre `"firma-scarpa"`
- `author` siempre `"Ricardo Scarpa"`
- `title` usa el TÍTULO SEO del Paso 2 (descriptivo, keyword-first)
- `slug` contiene las keywords más relevantes
- `tags` máximo 5, incluyen el nombre propio del sistema/caso analizado
- `pdf` referencia al informe de origen (fuente del análisis, no destino de descarga)

---

### Paso 4 — Escribir el artículo largo

**Estructura obligatoria:**

1. **Apertura** — La primera línea es el gancho editorial del Paso 2, desarrollado en 2-4 frases. Debe activar la tensión central desde el primer párrafo. La keyword principal aparece aquí.

2. **Contexto con criterio** (H2) — No es un resumen de antecedentes genéricos. Es el marco que hace comprensible la tesis: qué estaba ocurriendo antes, por qué importa ahora, qué cambia con este análisis.

3. **El núcleo del argumento** (H2) — La tesis central del informe desarrollada con profundidad. Aquí va la doctrina, la jurisprudencia, los datos más sólidos. Mínimo 600 palabras.

4. **Secciones de desarrollo** (2-3 H2 adicionales) — Cada sección aborda un ángulo distinto: implicaciones prácticas, comparativa normativa, casos concretos, matices y excepciones. Cada H2 debe incluir keywords secundarias de forma natural.

5. **La pregunta que el análisis no puede cerrar** (H2 opcional) — Si el informe deja dilemas abiertos, esta sección los formula con honestidad intelectual. No es un defecto: es una señal de rigor.

6. **Conclusiones** — Bullets accionables (máximo 7). Qué debe saber o hacer un jurista después de leer. Concretos, no genéricos.

**Longitud objetivo:** 2.000-4.000 palabras.

---

### Paso 5 — Reglas de estilo (obligatorias)

**Voz humana con autoridad:** El texto lo escribe un jurista con criterio propio.

- Variación real en longitud de oraciones: cortas, medias y largas mezcladas
- Reflexiones que parecen surgir mientras se escribe: "Lo que más me llama la atención...", "Aquí es donde el análisis se complica", "Y esto, en el ámbito jurídico, no es un detalle menor"
- Alguna duda razonable expresada cuando el análisis no da respuesta definitiva
- Conectores variados: "Sin embargo", "Dicho esto", "Ahora bien", "Lo que resulta llamativo es", "Conviene recordar que" — nunca repetir el mismo
- Sin listas en el cuerpo del texto salvo las conclusiones finales
- Latinismos en cursiva: *prima facie*, *Human in the Loop*, *ratio decidendi*, etc.
- Los H2 son doctrinales y evocadores, no genéricos

**SEO en artículo largo:**
- Keyword principal en el primer párrafo y en al menos 2 H2
- Keywords long-tail distribuidas naturalmente en el cuerpo
- La meta description responde: qué analiza + dato más potente + conclusión
- Sin keyword stuffing: densidad natural, no forzada

**Lo que arruina el artículo largo:**
- Empezar con contexto genérico ("En los últimos años, la inteligencia artificial...")
- Desarrollar el informe capítulo por capítulo como índice
- H2 simétricos y perfectos que no suenan a persona real
- Conclusiones que repiten lo que ya se dijo en el cuerpo
- Tono neutro de resumen ejecutivo en lugar de criterio propio

---

### Ejemplo de H2 bien resueltos

Para un análisis sobre IA en la justicia argentina:

✅ `## Un sistema que no adivina, sino que deduce`
✅ `## Los números que cambiaron la conversación`
✅ `## Donde la automatización tropieza con la garantía de defensa`
✅ `## Lo que Argentina resolvió y España sigue debatiendo`
✅ `## La pregunta que ningún reglamento ha respondido todavía`

❌ `## Contexto y Marco Teórico`
❌ `## Análisis del Sistema`
❌ `## Implicaciones Jurídicas`
❌ `## Conclusiones y Recomendaciones`

---

### Paso 6 — Entregar el archivo y comandos de publicación

Guardar el MDX en `/mnt/user-data/outputs/[slug].mdx` y presentarlo con `present_files`.

Tras el archivo, mostrar el bloque PowerShell de publicación:

```powershell
cd C:\Proyectos\derecho-artificial
mkdir "content\firma-scarpa\[SLUG]" -Force
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-MDX].mdx" "content\firma-scarpa\[SLUG]\index.mdx"
Copy-Item "$env:USERPROFILE\Downloads\[NOMBRE-PDF].pdf" "public\fuentes\"
node scripts/update-glosario.cjs
git add .
git commit -m "feat(firma-scarpa): [título corto en minúsculas]"
git push
```

URL resultante:
`https://www.derechoartificial.com/firma-scarpa/[SLUG]`
