---
name: publicacion-completa-pdf
description: "Automatiza el flujo COMPLETO de publicación: desde un PDF hasta publicación en web + redes sociales en un solo paso. Lee el PDF, genera el post MDX, valida, crea título SEO, añade interlinking, publica y genera textos para X/LinkedIn/Facebook automáticamente. Usar cuando el usuario diga 'publica esto directamente', 'publicar todo con este PDF', 'quiero que salga a web y redes', o cualquier variante que indique automatización completa sin pasos intermedios."
---

# Superskill: Publicación Completa desde PDF

## 🎯 Propósito

Automatiza el **flujo completo de publicación** en un solo comando:
```
PDF → MDX → Validación → Titulación SEO → Interlinking → Publicación → Redes Sociales
```

Sin intervención manual entre pasos. El usuario sube un PDF y obtiene:
- ✅ Post publicado en web
- ✅ URL lista para compartir
- ✅ Textos para X, LinkedIn, Facebook (listos para copiar-pegar)
- ✅ Interlinking automático creado

---

## 📋 Flujo Completo Paso a Paso

### PASO 1: Análisis del PDF

**Acción:** Leer el PDF adjunto completamente.

**Determinar:**
- **Tipo de documento**: sentencia, normativa, informe, resolución, etc.
- **Fecha del documento**: para historial, pero la publicación usa HOY
- **Tema principal**: para keywords y sección
- **Propuesta de sección**:
  - Sentencias/casos → `jurisprudencia`
  - Leyes/normas/reglamentos → `normativa`
  - Informes de autor → `firma-scarpa`
  - Jurisprudencia internacional/extranjera → `jurisprudencia`
  - Artículos doctrinales propios → `firma-scarpa` o `etica-ia`

**Validar:** ¿El PDF es legible y contiene contenido suficiente para un post?
- Si no: detener aquí y avisar al usuario

---

### PASO 2: Generar MDX Hook

**Acción:** Invocar automáticamente el skill apropiado según tipo:

| Tipo de Doc | Skill a usar | Output |
|-------------|-------------|--------|
| Normativa/Ley | `hook-generico-pdf` | MDX gancho 800-1100 palabras |
| Sentencia/Caso | `courtlistener-analyzer` (si URL) o `hook-generico-pdf` | MDX análisis |
| Informe propio | `articulo-firma-scarpa` (si >2k palabras esperadas) o `hook-firma-scarpa` | MDX largo o gancho |
| Análisis IA | `analisis-juridico-ia` | MDX doctrinal |

**Resultado esperado:** 
- Archivo `.mdx` con estructura correcta
- Frontmatter incompleto (falta título SEO final, slug, fecha correcta)
- Contenido validado

**IMPORTANTE:** La fecha en el frontmatter DEBE SER HOY, no la fecha del documento.

---

### PASO 3: Validación del MDX

**Acción:** Invocar skill `validar-post-antes-publicar`

**Verificar:**
- ✅ Frontmatter bien formado (entre `---` y `---`)
- ✅ Campos obligatorios presentes: title, date, section, slug, category
- ✅ Valores válidos: section es una de las secciones permitidas
- ✅ Coherencia: slug coincide con section, date en formato YYYY-MM-DD
- ✅ PDF existe (si está referenciado)
- ✅ Sin caracteres especiales rotos en template strings

**Si hay errores:** Invocar skill `debug-post-publicacion` para fijar automáticamente

**Si está OK:** Continuar

---

### PASO 4: Titulación y Gancho SEO

**Acción:** Invocar skill `titulacion-derechoartificial`

**Hacer:**
1. Analizar el contenido del MDX generado
2. Aplicar las 6 técnicas de gancho:
   - Paradoja en dos tiempos
   - Cifra imposible
   - Sujeto inesperado
   - Dato extremo
   - Pregunta incómoda
   - Tensión temporal
3. Generar 3-5 opciones de título SEO (55-65 caracteres)
4. Elegir la mejor y extraer el gancho de primera línea

**Actualizar el MDX con:**
- `title`: Título SEO final (reemplazar el genérico)
- Asegurar que el gancho de primera línea está optimizado
- Generar `slug` automático desde el título (kebab-case)

---

### PASO 5: Interlinking Automático

**Acción:** Invocar skill `interlinking-da`

**Hacer:**
1. Escanear términos clave del post
2. Buscar posts relacionados en derechoartificial.com
3. Crear 4-6 enlaces internos contextualmente relevantes
4. Inyectar enlaces en el MDX usando sintaxis Markdown: `[texto](ruta)`

**Ubicación de enlaces:**
- Primeras 200 palabras: 1-2 enlaces de contexto amplio
- Cuerpo principal: 2-3 enlaces temáticos
- Conclusión/final: 1 enlace a lecturas relacionadas

---

### PASO 6: Revisión Editorial (Opcional, SOLO si el usuario lo indicó)

**Acción:** Invocar skill `harvard-law-review-editor` (SOLO si el usuario dijo "revisa" o "edita")

**Hacer:**
- Revisar ortografía, estilo académico, coherencia jurídica
- Corregir errores sin cambiar el sentido
- Mantener la voz del autor

**Si NO lo indicó el usuario:** Saltar este paso (ahorrar tiempo)

---

### PASO 7: Preparar para Publicación

**Acción:** Preparar estructura local en PowerShell (instrucciones para el usuario)

**Generar bloque de comandos PowerShell:**
```powershell
cd C:\Proyectos\derecho-artificial

# 1. Crear carpeta
mkdir "content\{SECTION}\{SLUG}" -Force

# 2. Copiar MDX
Copy-Item "$env:USERPROFILE\Downloads\{SLUG}.mdx" "content\{SECTION}\{SLUG}\index.mdx"

# 3. Copiar PDF (si existe)
Copy-Item "$env:USERPROFILE\Downloads\{PDF_NAME}" "public\fuentes\{PDF_NAME}"

# 4. Actualizar glosario
node scripts/update-glosario.cjs

# 5. Git
git add .
git commit -m "feat({SECTION}): {titulo-corto-en-minusculas}"
git push
```

**Nota:** NO ejecutar automáticamente. El usuario copia-pega en su terminal local.

---

### PASO 8: Publicación

**Acción:** Instruir al usuario para ejecutar los comandos PowerShell

**Verificación post-publicación (1-2 minutos después):**
- ¿El deploy de Vercel completó sin errores?
- ¿El post aparece en la sección correspondiente?
- ¿El enlace al PDF funciona?

Si hay errores → Invocar `debug-post-publicacion`

---

### PASO 9: Generación de Textos para Redes Sociales

**Acción:** Invocar skill `social-media-derechoartificial`

**Input:**
- URL del post publicado
- Título del post
- Primera línea (gancho)

**Output:**
- **Tweet para X**: 280 caracteres, con emoji, hashtags, CTA
- **Post LinkedIn**: 2-3 párrafos, tono profesional, CTA
- **Post Facebook**: 1-2 párrafos, tono accesible, emoji, CTA

**Formato de entrega:**
```
═══════════════════════════════════════════════════════════

📱 TEXTO PARA X (Twitter)
[Tweet listo para copiar-pegar]

💼 TEXTO PARA LINKEDIN
[Post listo para copiar-pegar]

📘 TEXTO PARA FACEBOOK
[Post listo para copiar-pegar]

═══════════════════════════════════════════════════════════
```

---

## ✅ Checklist Final de Entrega

Antes de mostrar al usuario el resultado final, verificar:

- [ ] PDF fue leído completamente
- [ ] Sección propuesta es correcta
- [ ] MDX valida sin errores
- [ ] Título SEO está optimizado (55-65 caracteres)
- [ ] Slug está en kebab-case y coincide con contenido
- [ ] Fecha es HOY (YYYY-MM-DD)
- [ ] Interlinking: mínimo 4 enlaces internos
- [ ] PDF está en frontmatter si existe
- [ ] Todos los campos obligatorios están presentes
- [ ] Textos para redes están listos

---

## 📊 Output Final para el Usuario

Mostrar en este orden:

```
✅ PUBLICACIÓN COMPLETA LISTA

📄 POST GENERADO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Título: [Título SEO final]
Sección: {SECTION}
Palabras: {COUNT}
Lectura: {TIME} min
Slug: {slug-propuesto}
Fecha: {HOY}

📥 INSTRUCCIONES PARA PUBLICAR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[PowerShell commands aquí]

Cuando termine el deploy (1-2 min), el post estará en:
https://www.derechoartificial.com/{SECTION}/{slug}

📱 TEXTOS PARA REDES (copiar-pegar)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Textos para X, LinkedIn, Facebook]

🔗 INTERLINKINGS CREADOS: 4
→ [Enlace 1 contexto]
→ [Enlace 2 temático]
→ [Enlace 3 temático]
→ [Enlace 4 conclusión]
```

---

## 🎬 Cómo Usar Este Superskill

**Usuario dice:**
- "Publica este PDF directamente"
- "Quiero que salga a web y redes"
- "Publicar todo con esto"
- "Flujo completo"

**Tú:**
1. Ejecuta mentalmente este flujo completo
2. Invoca skills en orden: entrada → validación → titulación → interlinking → (opcional: revisión) → mostrar instrucciones de publicación → redes
3. Entrega checklist final arriba

**Resultado:** El usuario copia-pega un comando PowerShell, espera 2 minutos, y el post está en web + textos para redes listos.

---

## ⚠️ Casos Especiales

### Si el PDF es muy antiguo (antes de 2023)
- Avisar al usuario: "Este documento es de {YEAR}. La fecha de publicación será HOY. ¿OK?"
- Si user confirma: continuar
- Si user rechaza: proponer redactar un análisis nuevo usando `analisis-juridico-ia`

### Si el PDF es de baja calidad (imágenes escaneadas, OCR pobre)
- Avisar: "El PDF no es legible. Necesito intervención manual."
- Sugerir: "¿Puedes proporcionar versión en texto o documento original?"

### Si el tema es muy especializado
- Invocar `harvard-law-review-editor` automáticamente para revisión de rigor
- Avisar al usuario: "Contenido especializado. Se ejecutó revisión editorial automática."

### Si hay error en publicación
- Invocar `debug-post-publicacion` automáticamente
- Mostrar el error y la solución
- Sugerir: "¿Reintentar con la solución aplicada?"

---

## 📈 Métricas de Éxito

Cuando uses este superskill, deberías lograr:
- ⏱️ Tiempo total: 5-10 minutos (vs. 30-45 minutos manual)
- ✅ 0 errores en publicación (validación automática)
- 📱 3 textos para redes listos (vs. tener que escribirlos después)
- 🔗 4+ interlinkings creados (vs. olvidar hacerlo)
- 📊 Post posicionado en top 3 de keywords en 2-3 semanas (por SEO optimizado)
