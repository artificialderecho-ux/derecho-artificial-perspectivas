import { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/', '/_next/', '/admin/', '/search?*'],
      },
    ],
    sitemap: 'https://decisionandlaw.com/sitemap.xml',
    host: 'https://decisionandlaw.com',
  }
}
