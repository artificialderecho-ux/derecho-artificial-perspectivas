import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getStateBySlug, US_STATES } from '@/lib/states'
import { breadcrumbSchema, faqSchema, stateTrackerSchema } from '@/lib/schema'

// ISR: revalidate every 24 hours (regulation data changes slowly)
export const revalidate = 86400

// ─── Static params for all 50 states (SSG at build) ─────────────────────────
export async function generateStaticParams() {
  return US_STATES.map((state) => ({ state: state.slug }))
}

// ─── Dynamic metadata per state ──────────────────────────────────────────────
export async function generateMetadata({ params }: { params: { state: string } }): Promise<Metadata> {
  const state = getStateBySlug(params.state)
  if (!state) return {}

  const title = `${state.name} AI Legal Regulation Tracker 2025`
  const description = `Track AI legislation, bar association ethics opinions, and legal tech regulations in ${state.name}. Updated weekly for ${state.name} attorneys.`
  const url = `https://decisionandlaw.com/tracker/state/${state.slug}`

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title,
      description,
      url,
      type: 'website',
    },
  }
}

// ─── Page component ───────────────────────────────────────────────────────────
export default function StateTrackerPage({ params }: { params: { state: string } }) {
  const state = getStateBySlug(params.state)
  if (!state) notFound()

  const url = `https://decisionandlaw.com/tracker/state/${state.slug}`

  const statusColors = {
    enacted: 'bg-green-100 text-green-800 border-green-200',
    'active-legislation': 'bg-yellow-100 text-yellow-800 border-yellow-200',
    monitoring: 'bg-blue-100 text-blue-800 border-blue-200',
    'no-activity': 'bg-gray-100 text-gray-600 border-gray-200',
  }

  const statusLabels = {
    enacted: '✅ Law Enacted',
    'active-legislation': '⚡ Active Legislation',
    monitoring: '👁 Monitoring',
    'no-activity': '— No Activity',
  }

  const faqs = [
    {
      question: `Does ${state.name} have any AI regulation for attorneys?`,
      answer: `${state.name} currently has a status of "${statusLabels[state.aiLegalStatus]}" regarding AI regulation affecting legal practice. ${state.aiLegalStatus === 'enacted' ? `${state.name} has passed legislation that attorneys must be aware of when using AI tools.` : `Monitor this page for updates as the regulatory landscape evolves.`}`,
    },
    {
      question: `What is the ${state.barAssociation}'s position on AI in legal practice?`,
      answer: `The ${state.barAssociation} (${state.barUrl}) is the governing body for attorneys in ${state.name}. Check their official website for the latest ethics opinions on AI tool usage in legal practice.`,
    },
    {
      question: `Are there any pending AI bills in the ${state.name} legislature?`,
      answer: `You can track current AI-related bills through the ${state.name} legislature at ${state.legislatureUrl}. Decision & Law monitors this page weekly and updates the status badge accordingly.`,
    },
  ]

  // JSON-LD schemas
  const schemas = [
    breadcrumbSchema([
      { name: 'Home', url: 'https://decisionandlaw.com' },
      { name: 'Regulation Tracker', url: 'https://decisionandlaw.com/tracker' },
      { name: 'States', url: 'https://decisionandlaw.com/tracker/state' },
      { name: state.name, url },
    ]),
    faqSchema(faqs),
    stateTrackerSchema({
      stateName: state.name,
      url,
      description: `AI legal regulation tracker for ${state.name} — legislation status, bar association ethics, and compliance guidance for ${state.name} attorneys.`,
    }),
  ]

  return (
    <>
      {/* JSON-LD injection */}
      {schemas.map((schema, i) => (
        <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      ))}

      <article className="max-w-4xl mx-auto px-4 py-12">
        {/* Breadcrumbs */}
        <nav aria-label="Breadcrumb" className="text-sm text-gray-500 mb-8">
          <ol className="flex gap-2">
            {['Home', 'Tracker', 'States', state.name].map((crumb, i, arr) => (
              <li key={crumb} className="flex items-center gap-2">
                <span className={i === arr.length - 1 ? 'text-gray-900 font-medium' : ''}>{crumb}</span>
                {i < arr.length - 1 && <span>/</span>}
              </li>
            ))}
          </ol>
        </nav>

        {/* Header */}
        <header className="mb-10">
          <div className="flex items-center gap-4 mb-4">
            <span className={`text-sm font-semibold px-3 py-1 rounded-full border ${statusColors[state.aiLegalStatus]}`}>
              {statusLabels[state.aiLegalStatus]}
            </span>
            <span className="text-sm text-gray-500">Updated weekly</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            {state.name} AI Legal Regulation Tracker
          </h1>
          <p className="text-xl text-gray-600">
            Your weekly briefing on AI legislation, bar ethics opinions, and legal tech compliance for{' '}
            {state.name} attorneys. Capital: {state.capital} · Bar: {state.barAssociation}.
          </p>
        </header>

        {/* Key Info Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {[
            { label: 'State', value: state.name, sub: state.abbreviation },
            { label: 'Region', value: state.region, sub: 'US Region' },
            { label: 'Bar Association', value: state.barAssociation, sub: 'Governing body', link: state.barUrl },
          ].map(({ label, value, sub, link }) => (
            <div key={label} className="border border-gray-200 rounded-lg p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">{label}</p>
              {link ? (
                <a href={link} target="_blank" rel="noopener noreferrer" className="font-semibold text-blue-600 hover:underline text-sm">
                  {value}
                </a>
              ) : (
                <p className="font-semibold text-gray-900">{value}</p>
              )}
              <p className="text-xs text-gray-400 mt-1">{sub}</p>
            </div>
          ))}
        </section>

        {/* FAQ Section (boosts featured snippets) */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {faqs.map(({ question, answer }) => (
              <div key={question} className="border-l-4 border-blue-500 pl-4">
                <h3 className="font-semibold text-gray-900 mb-2">{question}</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{answer}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Related states (internal linking) */}
        <section>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Other {state.region} States</h2>
          <div className="flex flex-wrap gap-2">
            {US_STATES.filter((s) => s.region === state.region && s.slug !== state.slug).map((s) => (
              <a
                key={s.slug}
                href={`/tracker/state/${s.slug}`}
                className="text-sm px-3 py-1 bg-gray-100 hover:bg-gray-200 rounded-full text-gray-700 transition-colors"
              >
                {s.name}
              </a>
            ))}
          </div>
        </section>
      </article>
    </>
  )
}
