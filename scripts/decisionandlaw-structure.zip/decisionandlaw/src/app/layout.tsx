import type { Metadata } from 'next'
import { Inter, Playfair_Display } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://decisionandlaw.com'),
  title: {
    default: 'Decision & Law — Legal Tech Intelligence for US Attorneys',
    template: '%s | Decision & Law',
  },
  description:
    'The definitive resource for US attorneys navigating AI legal tools, AI regulation, and legal tech legislation. Expert analysis for solo practitioners and small firms.',
  keywords: ['legal tech', 'AI legal tools', 'legal AI regulation', 'law firm technology', 'attorney AI tools'],
  authors: [{ name: 'Decision & Law Editorial Team' }],
  creator: 'Decision & Law',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://decisionandlaw.com',
    siteName: 'Decision & Law',
    title: 'Decision & Law — Legal Tech Intelligence for US Attorneys',
    description: 'Expert coverage of AI tools, regulation, and legislation shaping US legal practice.',
    images: [{ url: '/og-default.jpg', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    site: '@decisionandlaw',
    creator: '@decisionandlaw',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-video-preview': -1, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  alternates: {
    canonical: 'https://decisionandlaw.com',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="bg-white text-gray-900 font-sans antialiased">
        <Navbar />
        <main id="main-content">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
