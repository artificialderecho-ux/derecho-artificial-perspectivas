// ─── Article (News) ───────────────────────────────────────────────────────────
export type ArticleCategory = 'legislation' | 'case-law' | 'ethics' | 'ai-regulation'
export type ArticleSubcategory =
  | 'federal'
  | 'state'
  | 'ai-regulation'
  | 'supreme-court'
  | 'circuit-courts'
  | 'ai-liability'
  | 'aba-opinions'

export interface Author {
  name: string
  slug: string
  title: string
  credentials: string[]  // e.g. ["JD", "LLM"]
  bio: string
  image: string
  linkedIn?: string
  twitter?: string
}

export interface Article {
  slug: string
  title: string
  description: string
  content: string       // MDX content
  category: ArticleCategory
  subcategory: ArticleSubcategory
  state?: string        // slug, if state-specific
  author: Author
  datePublished: string // ISO 8601
  dateModified?: string
  image?: string
  imageAlt?: string
  keywords: string[]
  readingTime: number   // minutes
  relatedArticles?: string[] // slugs
  relatedTrackerPages?: string[] // state slugs
  featured?: boolean
}

// ─── Tool (AI Legal Tool) ─────────────────────────────────────────────────────
export type ToolCategory = 'legal-research' | 'drafting' | 'contract-management' | 'billing' | 'intake' | 'e-discovery' | 'compliance'
export type FirmSize = 'solo' | 'small' | 'medium' | 'enterprise'
export type PricingModel = 'subscription' | 'per-seat' | 'usage-based' | 'free' | 'freemium'

export interface ToolPricing {
  model: PricingModel
  startingAt?: number   // USD/month
  hasFreeTrialOrTier: boolean
  pricingUrl: string
}

export interface Tool {
  slug: string
  name: string
  tagline: string
  description: string
  content: string       // MDX review content
  category: ToolCategory
  targetFirmSize: FirmSize[]
  pricing: ToolPricing
  website: string
  rating: number        // 1-5
  pros: string[]
  cons: string[]
  bestFor: string
  notFor: string
  abaEthicsConsiderations?: string
  lastReviewed: string  // ISO 8601
  author: Author
  image?: string
  featured?: boolean
}

// ─── Regulation (Tracker) ─────────────────────────────────────────────────────
export type RegulationStatus = 'enacted' | 'active-legislation' | 'monitoring' | 'no-activity'

export interface Regulation {
  id: string
  title: string
  jurisdiction: string  // state slug or 'federal'
  status: RegulationStatus
  summary: string
  billNumber?: string
  effectiveDate?: string
  legislatureUrl?: string
  abaOpinionNumber?: string
  affectsLawFirmSize: FirmSize[]
  practiceAreas: string[]
  lastUpdated: string   // ISO 8601
}
