// JSON-LD Schema builders for decisionandlaw.com
// Covers: NewsArticle, FAQPage, BreadcrumbList, Person, WebSite

const BASE_URL = 'https://decisionandlaw.com'
const ORG_NAME = 'Decision & Law'

// ─── WebSite (homepage only) ──────────────────────────────────────────────────
export function websiteSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: ORG_NAME,
    url: BASE_URL,
    description: 'Legal tech intelligence for US attorneys: AI tools, regulation tracker, and legislation coverage.',
    potentialAction: {
      '@type': 'SearchAction',
      target: { '@type': 'EntryPoint', urlTemplate: `${BASE_URL}/search?q={search_term_string}` },
      'query-input': 'required name=search_term_string',
    },
    publisher: {
      '@type': 'Organization',
      name: ORG_NAME,
      url: BASE_URL,
      logo: { '@type': 'ImageObject', url: `${BASE_URL}/logo.png` },
    },
  }
}

// ─── NewsArticle ──────────────────────────────────────────────────────────────
export function newsArticleSchema({
  title,
  description,
  url,
  image,
  datePublished,
  dateModified,
  authorName,
  authorUrl,
  section,
  keywords,
}: {
  title: string
  description: string
  url: string
  image?: string
  datePublished: string
  dateModified?: string
  authorName: string
  authorUrl: string
  section: string
  keywords?: string[]
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'NewsArticle',
    headline: title,
    description,
    url,
    image: image ?? `${BASE_URL}/og-default.jpg`,
    datePublished,
    dateModified: dateModified ?? datePublished,
    author: {
      '@type': 'Person',
      name: authorName,
      url: authorUrl,
    },
    publisher: {
      '@type': 'Organization',
      name: ORG_NAME,
      url: BASE_URL,
      logo: { '@type': 'ImageObject', url: `${BASE_URL}/logo.png` },
    },
    articleSection: section,
    keywords: keywords?.join(', '),
    mainEntityOfPage: { '@type': 'WebPage', '@id': url },
    isAccessibleForFree: true,
  }
}

// ─── FAQPage ──────────────────────────────────────────────────────────────────
export function faqSchema(faqs: { question: string; answer: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(({ question, answer }) => ({
      '@type': 'Question',
      name: question,
      acceptedAnswer: { '@type': 'Answer', text: answer },
    })),
  }
}

// ─── BreadcrumbList ───────────────────────────────────────────────────────────
export function breadcrumbSchema(items: { name: string; url: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  }
}

// ─── Person (author E-E-A-T) ──────────────────────────────────────────────────
export function personSchema({
  name,
  url,
  image,
  description,
  jobTitle,
  credentials,
  sameAs,
}: {
  name: string
  url: string
  image?: string
  description: string
  jobTitle: string
  credentials?: string[]
  sameAs?: string[]
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Person',
    name,
    url,
    image,
    description,
    jobTitle,
    hasCredential: credentials?.map((cred) => ({
      '@type': 'EducationalOccupationalCredential',
      credentialCategory: cred,
    })),
    sameAs,
    worksFor: {
      '@type': 'Organization',
      name: ORG_NAME,
      url: BASE_URL,
    },
  }
}

// ─── LegalService (tracker state pages) ───────────────────────────────────────
export function stateTrackerSchema({
  stateName,
  url,
  description,
}: {
  stateName: string
  url: string
  description: string
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: `AI Legal Regulation Tracker — ${stateName}`,
    url,
    description,
    about: {
      '@type': 'LegalService',
      name: `${stateName} AI Legal Regulation`,
      areaServed: { '@type': 'State', name: stateName, containedInPlace: { '@type': 'Country', name: 'United States' } },
    },
    publisher: {
      '@type': 'Organization',
      name: ORG_NAME,
      url: BASE_URL,
    },
  }
}
