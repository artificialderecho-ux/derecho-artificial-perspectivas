/** @type {import('next').NextConfig} */
const nextConfig = {
  // Performance
  compress: true,
  poweredByHeader: false,

  // Image optimization
  images: {
    formats: ['image/avif', 'image/webp'],
    remotePatterns: [
      { protocol: 'https', hostname: 'images.decisionandlaw.com' },
    ],
  },

  // Redirects for SEO hygiene
  async redirects() {
    return [
      // Ensure trailing-slash consistency (no trailing slash)
      { source: '/news/', destination: '/news', permanent: true },
      { source: '/tools/', destination: '/tools', permanent: true },
      { source: '/tracker/', destination: '/tracker', permanent: true },
      { source: '/guides/', destination: '/guides', permanent: true },
    ]
  },

  // Experimental features
  experimental: {
    // Partial prerendering for news pages (Next.js 15)
    ppr: true,
  },
}

module.exports = nextConfig
