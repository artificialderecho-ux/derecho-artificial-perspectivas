# decisionandlaw.com

> Legal Tech informational media for the US market — AI Tools + AI Regulation Tracker

## Stack

- **Framework**: Next.js 15 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS
- **Deployment**: Vercel
- **CMS**: MDX files + Contentlayer (or Sanity for scaling)
- **Analytics**: Google Analytics 4 + Google Search Console
- **Schema**: JSON-LD structured data (NewsArticle, FAQPage, LegalService)

---

## Folder Structure

```
src/
├── app/                          # Next.js App Router pages
│   ├── layout.tsx                # Root layout (fonts, meta, navbar, footer)
│   ├── page.tsx                  # Homepage
│   ├── sitemap.ts                # Dynamic XML sitemap
│   ├── robots.ts                 # robots.txt config
│   │
│   ├── news/                     # SILO 1 — News & Current Affairs
│   │   ├── page.tsx              # /news — News hub with filters
│   │   ├── legislation/
│   │   │   ├── page.tsx          # /news/legislation — Legislation hub
│   │   │   ├── federal/
│   │   │   │   └── page.tsx      # /news/legislation/federal
│   │   │   ├── state/
│   │   │   │   ├── page.tsx      # /news/legislation/state — State index
│   │   │   │   └── [state]/
│   │   │   │       └── page.tsx  # /news/legislation/state/california
│   │   │   └── ai-regulation/
│   │   │       └── page.tsx
│   │   ├── case-law/
│   │   │   ├── page.tsx
│   │   │   ├── supreme-court/page.tsx
│   │   │   ├── circuit-courts/page.tsx
│   │   │   └── ai-liability/page.tsx
│   │   ├── ethics/
│   │   │   └── page.tsx
│   │   └── [slug]/
│   │       └── page.tsx          # Individual news articles
│   │
│   ├── tools/                    # SILO 2 — AI Legal Tools (Nicho 1)
│   │   ├── page.tsx              # /tools — Tools hub
│   │   ├── for-solo-practitioners/page.tsx
│   │   ├── for-small-firms/page.tsx
│   │   ├── [category]/
│   │   │   └── page.tsx          # /tools/research, /tools/drafting, etc.
│   │   ├── compare/
│   │   │   └── [slug]/
│   │   │       └── page.tsx      # /tools/compare/clio-vs-mycase (pSEO)
│   │   └── reviews/
│   │       └── [tool]/
│   │           └── page.tsx      # /tools/reviews/harvey-ai
│   │
│   ├── tracker/                  # SILO 3 — AI Regulation Tracker (Nicho 2)
│   │   ├── page.tsx              # /tracker — Regulation tracker hub
│   │   ├── state/
│   │   │   ├── page.tsx          # /tracker/state — 50-state index
│   │   │   └── [state]/
│   │   │       └── page.tsx      # /tracker/state/texas (pSEO)
│   │   ├── aba-opinions/
│   │   │   └── page.tsx
│   │   ├── federal-ai-policy/
│   │   │   └── page.tsx
│   │   └── malpractice-cases/
│   │       └── page.tsx
│   │
│   ├── guides/                   # Evergreen pillar content
│   │   ├── page.tsx
│   │   └── [slug]/
│   │       └── page.tsx
│   │
│   ├── authors/                  # E-E-A-T author profiles
│   │   ├── page.tsx
│   │   └── [author]/
│   │       └── page.tsx
│   │
│   └── newsletter/
│       └── page.tsx
│
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx            # Sticky nav with mega-menu
│   │   ├── Footer.tsx
│   │   └── Breadcrumbs.tsx       # SEO breadcrumbs + schema
│   ├── ui/
│   │   ├── ArticleCard.tsx       # News card component
│   │   ├── ToolCard.tsx          # Tool review card
│   │   ├── StateTracker.tsx      # Regulation status badge
│   │   ├── AuthorBox.tsx         # E-E-A-T author widget
│   │   ├── NewsletterCTA.tsx
│   │   └── TableOfContents.tsx   # Auto-generated TOC for long articles
│   └── seo/
│       ├── JsonLd.tsx            # JSON-LD schema injector
│       ├── OpenGraph.tsx         # OG tags
│       └── Breadcrumb.tsx
│
├── lib/
│   ├── metadata.ts               # Centralized metadata helpers
│   ├── schema.ts                 # JSON-LD schema builders
│   ├── states.ts                 # US states data for pSEO
│   ├── tools.ts                  # Tools data/fetching
│   └── news.ts                   # News fetching utilities
│
├── types/
│   ├── article.ts
│   ├── tool.ts
│   └── regulation.ts
│
└── styles/
    └── globals.css               # Tailwind base + CSS variables
```

---

## SEO Architecture Decisions

### 1. URL Strategy
- Flat where possible (max 3 levels deep)
- Keyword-rich slugs: `/news/legislation/state/california-ai-law-2025`
- Programmatic pages for 50 states × regulation topics

### 2. Schema Markup (JSON-LD)
- `NewsArticle` on all news pages
- `FAQPage` on all guides and tracker pages
- `BreadcrumbList` sitewide
- `Person` on author pages (E-E-A-T)
- `WebSite` with `SearchAction` on homepage

### 3. Internal Linking Rules
- Every news article links to 2+ relevant tracker pages
- Every tool review links to relevant legislation/ethics pages
- Hub pages link to all spoke pages (not reverse)
- Use descriptive anchor text (no "click here")

### 4. Content Velocity (Phase 1)
- 3-5 news articles/week (legislation + case-law)
- 1 tool review/week
- 1 state tracker update/week
- Monthly ABA opinion analysis

---

## Deployment

```bash
# Install
npm install

# Dev
npm run dev

# Build
npm run build

# Deploy (auto via Vercel GitHub integration)
git push origin main
```

### Vercel Config (vercel.json)
- Edge runtime for tracker pages (real-time data)
- ISR (Incremental Static Regeneration) for news: revalidate 3600s
- Static generation for guides and tool reviews

---

## Phase Roadmap

| Phase | Duration | Focus | Target Pages |
|-------|----------|-------|-------------|
| 1 | Months 1-3 | News authority (legislation + case-law) | 50-80 articles |
| 2 | Months 3-6 | Tool reviews + comparisons | 30-50 tool pages |
| 3 | Months 6-12 | Regulation Tracker (50 states pSEO) | 150+ tracker pages |
| 4 | Month 12+ | Newsletter monetization + B2B leads | — |
